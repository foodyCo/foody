# Quickstart

15-минутный туториал: вы пройдёте путь от первого запроса к публичной ленте до публикации поста и его одобрения через модерацию. После этого вы можете переходить к [reference](reference/) и подробно изучить конкретные ресурсы.

---

## 1. Что такое Foody API

Foody — REST API для постов о ресторанных блюдах: пользователь публикует фотографию блюда, описание, цену и рейтинг, подписывается на других пользователей и читает ленту. Все маршруты живут под префиксом `/api/v1/`; авторизация — JWT (Bearer-токен), формат ответов — JSON. Все ошибки DRF локализованы на русский (см. [conventions.md#language](conventions.md#language)).

---

## 2. Подготовка

Понадобятся:

- `curl` (или `httpie`),
- `python3` для парсинга JSON в shell,
- две роли — обычный пользователь и модератор.

Зафиксируйте базовый URL и тестовые аккаунты как переменные окружения. Тестовые аккаунты — публичные демо-учётки прода (см. [auth.md#staff-access](auth.md#staff-access)).

```bash
export BASE_URL='https://foody.press/api/v1'

# Обычный пользователь.
export USER_EMAIL='test_user1@test.local'
export USER_PASSWORD='foodytest123'

# Staff-модератор.
export ADMIN_EMAIL='admin@example.com'
export ADMIN_PASSWORD='admin123'
```

Под капотом API доступен также через Swagger UI — `https://foody.press/api/docs/`. Полная схема OpenAPI — `https://foody.press/api/schema/` (см. также [README.md](README.md)).

---

## 3. Получить JWT для обоих аккаунтов

JWT выдаётся на эндпоинте [`POST /auth/token/`](auth.md#jwt-obtain). Сначала обычный пользователь:

```bash
USER_TOKEN=$(
  curl -sS -X POST "$BASE_URL/auth/token/" \
    -H 'Content-Type: application/json' \
    -d "{\"email\":\"$USER_EMAIL\",\"password\":\"$USER_PASSWORD\"}" \
  | python3 -c 'import json,sys;print(json.load(sys.stdin)["access"])'
)
echo "${USER_TOKEN:0:30}..."
```

Затем staff-токен (тем же эндпоинтом, разница только в email/пароле — см. [auth.md#staff-access](auth.md#staff-access)):

```bash
ADMIN_TOKEN=$(
  curl -sS -X POST "$BASE_URL/auth/token/" \
    -H 'Content-Type: application/json' \
    -d "{\"email\":\"$ADMIN_EMAIL\",\"password\":\"$ADMIN_PASSWORD\"}" \
  | python3 -c 'import json,sys;print(json.load(sys.stdin)["access"])'
)
```

**Throttle:** `/auth/token/` ограничен 10 запросами в минуту с одного IP ([conventions.md#throttle](conventions.md#throttle)). Не перелогинивайтесь в цикле — кешируйте access-токен, обновляйте через [`/auth/token/refresh/`](auth.md#jwt-refresh).

Ответ имеет вид `{"refresh": "...", "access": "..."}`. В заголовках всех последующих запросов используйте `Authorization: Bearer $TOKEN` ([auth.md#header](auth.md#header)).

---

## 4. Получить анонимный feed

Эндпоинт [`GET /posts/`](reference/posts.md) доступен без токена и возвращает только посты со `status='approved'` ([conventions.md#post-lifecycle](conventions.md#post-lifecycle)). Ответ — стандартная DRF-пагинация ([conventions.md#pagination](conventions.md#pagination)).

```bash
curl -sS "$BASE_URL/posts/?page=1&page_size=5" \
  -H 'Accept: application/json'
```

Сокращённый ответ:

```json
{
  "count": 5,
  "next": "https://foody.press/api/v1/posts/?page=2&page_size=5",
  "previous": null,
  "results": [
    {
      "id": 190,
      "user": {
        "id": 74,
        "username": "test_user2",
        "full_name": "Test User 2",
        "avatar": null,
        "is_following": false
      },
      "restaurant": 67,
      "restaurant_name": "Солнышко",
      "restaurant_address": "Крупская 35",
      "dish": 171,
      "dish_name": "Каша овсяная",
      "description": "Вкусная кашка как в детстве",
      "price": "200.00",
      "created_at": "2026-05-20T12:19:39.430751Z",
      "images": [
        { "id": 88, "image": "/media/post_images/1727.jpg", "uploaded_at": "2026-05-20T12:19:39.454899Z" }
      ],
      "statistics": { "likes_count": 1, "saves_count": 1, "comments_count": 2, "rating": 4.0 },
      "tags": [
        { "id": 9, "name": "русская" },
        { "id": 74, "name": "каша" }
      ],
      "categories": [],
      "is_liked": false,
      "is_saved": false,
      "status": "approved",
      "rejection_reason": null
    }
  ]
}
```

`images[].image` приходит как **относительный** путь — фронт обязан склеивать его с `https://foody.press`, **не** с `BASE_URL` (`api/v1` в путях медиа нет; подробно — [conventions.md#media-urls](conventions.md#media-urls)).

> Готовые скрипты на curl/JS/Python — `examples/feed-anon.{curl.sh,js,py}`.

---

## 5. Подписаться на пользователя

Подписка — идемпотентный toggle через [`POST /users/{id}/subscribe/`](reference/users.md). Снятие — `DELETE` ([conventions.md#toggle-semantics](conventions.md#toggle-semantics)).

```bash
TARGET_USER_ID=74
curl -sS -X POST "$BASE_URL/users/$TARGET_USER_ID/subscribe/" \
  -H "Authorization: Bearer $USER_TOKEN"
```

Ответ:

```json
{ "status": "followed", "created": true }
```

`created: false` значит «уже был подписан». Подписаться на себя нельзя — 400 `{"error":"Нельзя подписаться на себя"}`. Путей `/follow/` и `/unfollow/` **не существует** (вернут 404) — см. [reference/users.md](reference/users.md) и [errors.md#404](errors.md#404).

> Готовый скрипт: `examples/follow-user.curl.sh`.

---

## 6. Опубликовать пост с фотографией

Создание поста — `multipart/form-data` на [`POST /posts/`](reference/posts.md). Файл изображения передаётся полем `uploaded_images` (можно повторять), теги — повторяющимся полем `tags_list`. Тип запроса принимает request-сериализатор `PostCreateSerializer`, а в ответе сервер уже отдаёт полный объект из `PostListSerializer` (вместе с `user`, `statistics`, `tags`, `images`).

```bash
curl -sS -X POST "$BASE_URL/posts/" \
  -H "Authorization: Bearer $USER_TOKEN" \
  -F "dish_name=Цезарь с курицей" \
  -F "description=Свежий, листья хрустят, заправка не жирная." \
  -F "price=450" \
  -F "rating=5" \
  -F "restaurant_name=Демо-кафе" \
  -F "restaurant_address=ул. Примерная, 1" \
  -F "uploaded_images=@./photo.jpg" \
  -F "tags_list=салат" \
  -F "tags_list=обед"
```

Ответ 201, сокращённо:

```json
{
  "id": 192,
  "user": {
    "id": 73,
    "username": "test_user1",
    "full_name": "Test User 1",
    "avatar": null,
    "is_following": false
  },
  "restaurant": 68,
  "restaurant_name": "Демо-кафе",
  "restaurant_address": "ул. Примерная, 1",
  "dish": 173,
  "dish_name": "Цезарь с курицей",
  "description": "Свежий, листья хрустят, заправка не жирная.",
  "price": "450.00",
  "created_at": "2026-05-20T20:15:51.424853Z",
  "images": [
    { "id": 89, "image": "/media/post_images/photo.jpg", "uploaded_at": "2026-05-20T20:15:51.430080Z" }
  ],
  "statistics": { "likes_count": 0, "saves_count": 0, "comments_count": 0, "rating": 0.0 },
  "tags": [
    { "id": 75, "name": "салат" },
    { "id": 76, "name": "обед" }
  ],
  "categories": [],
  "is_liked": false,
  "is_saved": false,
  "status": "pending",
  "rejection_reason": null
}
```

Запомните `id` — он понадобится в шагах 7 и 8:

```bash
POST_ID=192
```

> Готовые скрипты на curl/JS/Python — `examples/publish-post.{curl.sh,js,py}`.

---

## 7. Убедиться, что pending-пост НЕ виден в ленте

Сразу после создания пост в статусе `pending`. Пока модератор не одобрит, он не появится в `GET /posts/`:

```bash
curl -sS "$BASE_URL/posts/?page=1&page_size=5" \
  | python3 -c 'import json,sys;d=json.load(sys.stdin);print([r["id"] for r in d["results"]])'
```

`$POST_ID` в списке отсутствует — это by design ([conventions.md#post-lifecycle](conventions.md#post-lifecycle)).

Автор видит свои pending/rejected посты через [`GET /posts/my/`](reference/posts.md) и [`GET /posts/{id}/`](reference/posts.md) (расширенный `get_object`). Любой PATCH/PUT на `/posts/{id}/` сбрасывает статус обратно в `pending` — пост уходит на повторную модерацию.

---

## 8. Одобрить пост от лица staff

Эндпоинт [`POST /moderation/{id}/approve/`](reference/moderation.md) принимает только staff-токен ([auth.md#staff-access](auth.md#staff-access)). Очередь — [`GET /moderation/`](reference/moderation.md) (только `status=pending`, отдельная пагинация по 10 элементов).

```bash
# Проверить, что пост в очереди.
curl -sS "$BASE_URL/moderation/?page=1" \
  -H "Authorization: Bearer $ADMIN_TOKEN" \
  | python3 -c 'import json,sys;d=json.load(sys.stdin);print([r["id"] for r in d["results"]])'

# Одобрить.
curl -sS -X POST "$BASE_URL/moderation/$POST_ID/approve/" \
  -H "Authorization: Bearer $ADMIN_TOKEN"
```

Ответ:

```json
{ "status": "approved" }
```

Отклонение — `POST /moderation/{id}/reject/`. Можно передать `{"rejection_reason":"..."}` в теле; пост уходит в `rejected` и больше не появляется в очереди. **`approve` после `reject` вернёт 404** — queryset модерации фильтрует только `pending` ([reference/moderation.md](reference/moderation.md)).

> Готовый скрипт: `examples/moderation-approve.curl.sh`.

---

## 9. Увидеть пост в ленте

```bash
curl -sS "$BASE_URL/posts/?page=1&page_size=5" \
  | python3 -c 'import json,sys;d=json.load(sys.stdin);print([r["id"] for r in d["results"]])'
```

`$POST_ID` теперь стоит первым (сортировка по умолчанию — `-created_at,-id`, см. [conventions.md#filters](conventions.md#filters)). Поздравляем — полный цикл «регистрация → публикация → модерация → лента» пройден.

---

## 10. Куда дальше

- [auth.md](auth.md) — регистрация, refresh-токены, заголовок `Authorization`.
- [conventions.md](conventions.md) — пагинация, throttle, формат media-URL, фильтры, lifecycle постов.
- [errors.md](errors.md) — справочник кодов ответа и формат `{detail}` / `{field: [...]}` ([errors.md#drf-formats](errors.md#drf-formats)).
- [reference/users.md](reference/users.md) — управление пользователями, подписки, профиль.
- [reference/posts.md](reference/posts.md) — посты, лайки, сохранения, комментарии.
- [reference/moderation.md](reference/moderation.md) — модераторские эндпоинты.
- [reference/restaurants.md](reference/restaurants.md), [reference/categories.md](reference/categories.md) — справочные сущности.

Все примеры из этого quickstart лежат отдельными файлами в `examples/` и верифицируются прогоном против прода (см. `_pipeline.md §5 «Фаза 4»`).
