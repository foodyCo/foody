#!/usr/bin/env bash
# Одобрить пост в статусе pending от лица staff-модератора.
#
# Эндпоинты:
#   GET  /api/v1/moderation/                  — очередь pending (10 на страницу).
#   POST /api/v1/moderation/{id}/approve/     — апрув.
#   POST /api/v1/moderation/{id}/reject/      — отклонение (можно передать
#                                              {"rejection_reason":"..."} в теле).
#
# Auth: staff only (is_staff=True), 300 req/min. См. auth.md#staff-access.
# Замечание: approve после reject вернёт 404 — queryset фильтрует только pending.

set -euo pipefail

BASE_URL="${BASE_URL:-https://foody.press/api/v1}"
EMAIL="${EMAIL:-admin@example.com}"
PASSWORD="${PASSWORD:-admin123}"

# 1. Получить staff-токен.
ADMIN_TOKEN=$(
  curl --fail-with-body -sS -X POST "${BASE_URL}/auth/token/" \
    -H 'Content-Type: application/json' \
    -d "{\"email\":\"${EMAIL}\",\"password\":\"${PASSWORD}\"}" \
  | python3 -c 'import json,sys;print(json.load(sys.stdin)["access"])'
)

# 2. Прочитать первый pending-пост из очереди (передайте POST_ID через переменную,
#    если хотите одобрить конкретный пост).
POST_ID="${POST_ID:-}"
if [[ -z "$POST_ID" ]]; then
  POST_ID=$(
    curl --fail-with-body -sS \
      "${BASE_URL}/moderation/?page=1" \
      -H "Authorization: Bearer ${ADMIN_TOKEN}" \
    | python3 -c 'import json,sys;d=json.load(sys.stdin);print(d["results"][0]["id"] if d["results"] else "")'
  )
fi

if [[ -z "$POST_ID" ]]; then
  echo "Очередь модерации пуста." >&2
  exit 0
fi

# 3. Одобрить.
echo "--- approve POST_ID=${POST_ID} ---"
curl --fail-with-body -sS -X POST \
  "${BASE_URL}/moderation/${POST_ID}/approve/" \
  -H "Authorization: Bearer ${ADMIN_TOKEN}"
echo
