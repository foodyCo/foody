"""Получить публичную ленту анонимно (без JWT).

Запуск:   python3 feed-anon.py
Зависимость: requests (`pip install requests`).
Эндпоинт: GET /api/v1/posts/
Auth:     anon (60 req/min) — токен не нужен.

В конце печатает JSON-ответ в stdout (требование §3.4 пайплайна:
verify-loop Фазы 4 делает JSON-key diff против фактического curl-ответа).
"""

import json
import os
import sys

import requests

BASE_URL = os.environ.get("BASE_URL", "https://foody.press/api/v1")


def main() -> None:
    url = f"{BASE_URL}/posts/?page=1&page_size=5"
    response = requests.get(url, headers={"Accept": "application/json"}, timeout=10)
    if response.status_code != 200:
        sys.stderr.write(f"HTTP {response.status_code}: {response.text}\n")
        sys.exit(1)
    data = response.json()
    print(json.dumps(data, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
