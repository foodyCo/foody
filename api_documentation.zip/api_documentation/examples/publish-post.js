// Опубликовать пост с фотографией.
//
// Запуск:   IMAGE_PATH=./photo.jpg node publish-post.js
// Зависимости: только Node >= 18 (нативные fetch / FormData / Blob).
// Эндпоинт: POST /api/v1/posts/
// Auth:     authenticated user (300 req/min). JWT обязателен.
//
// ВАЖНО: ответ 201 возвращает пост со status="pending". До тех пор пока
// модератор не выполнит POST /api/v1/moderation/{id}/approve/, пост
// в общей ленте (GET /api/v1/posts/) не появится. См. conventions.md#post-lifecycle.
//
// В конце печатает JSON-ответ в stdout (требование §3.4 пайплайна).

import { openAsBlob } from 'node:fs';

const BASE_URL = process.env.BASE_URL || 'https://foody.press/api/v1';
const EMAIL = process.env.EMAIL || 'test_user1@test.local';
const PASSWORD = process.env.PASSWORD || 'foodytest123';
const IMAGE_PATH = process.env.IMAGE_PATH || './photo.jpg';

async function login() {
  const resp = await fetch(`${BASE_URL}/auth/token/`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: EMAIL, password: PASSWORD }),
  });
  if (!resp.ok) throw new Error(`login failed: HTTP ${resp.status} ${await resp.text()}`);
  const data = await resp.json();
  return data.access;
}

async function publish(token) {
  const form = new FormData();
  form.append('dish_name', 'Цезарь с курицей');
  form.append('description', 'Свежий, листья хрустят, заправка не жирная.');
  form.append('price', '450');
  form.append('rating', '5');
  form.append('restaurant_name', 'Демо-кафе');
  form.append('restaurant_address', 'ул. Примерная, 1');

  const blob = await openAsBlob(IMAGE_PATH);
  form.append('uploaded_images', blob, IMAGE_PATH.split('/').pop());

  // Повторяющиеся ключи дают список тегов.
  form.append('tags_list', 'салат');
  form.append('tags_list', 'обед');

  const resp = await fetch(`${BASE_URL}/posts/`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}` },
    body: form,
  });
  if (!resp.ok) throw new Error(`publish failed: HTTP ${resp.status} ${await resp.text()}`);
  return resp.json();
}

async function main() {
  const token = await login();
  const post = await publish(token);
  console.log(JSON.stringify(post, null, 2));
}

main().catch((err) => {
  console.error(err.message);
  process.exit(1);
});
