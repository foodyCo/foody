#!/usr/bin/env bash
# Получить публичную ленту анонимно (без JWT).
#
# Эндпоинт: GET /api/v1/posts/
# Auth:     anon (60 req/min) — токен не нужен.
# Ответ:    PageNumberPagination — {count, next, previous, results: [...]}.
#
# Возвращаются ТОЛЬКО посты со status='approved' (см. conventions.md#post-lifecycle).

set -euo pipefail

BASE_URL="${BASE_URL:-https://foody.press/api/v1}"

curl --fail-with-body -sS \
  "${BASE_URL}/posts/?page=1&page_size=5" \
  -H 'Accept: application/json'
