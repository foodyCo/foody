#!/usr/bin/env bash
# Опубликовать пост с фотографией.
#
# Эндпоинт: POST /api/v1/posts/
# Auth:     authenticated user (300 req/min). JWT обязателен.
# Content-Type: multipart/form-data (см. reference/posts.md и conventions.md#post-lifecycle).
#
# ВАЖНО: ответ 201 возвращает пост со status="pending". До тех пор пока
# модератор не выполнит POST /api/v1/moderation/{id}/approve/, пост
# в общей ленте (GET /api/v1/posts/) не появится. См. conventions.md#post-lifecycle.

set -euo pipefail

BASE_URL="${BASE_URL:-https://foody.press/api/v1}"
EMAIL="${EMAIL:-test_user1@test.local}"
PASSWORD="${PASSWORD:-foodytest123}"
IMAGE_PATH="${IMAGE_PATH:-./photo.jpg}"

if [[ ! -f "$IMAGE_PATH" ]]; then
  echo "Файл фотографии не найден: $IMAGE_PATH" >&2
  echo "Передайте путь через переменную IMAGE_PATH." >&2
  exit 1
fi

# 1. Получить JWT (login throttle 10/min).
TOKEN=$(
  curl --fail-with-body -sS -X POST "${BASE_URL}/auth/token/" \
    -H 'Content-Type: application/json' \
    -d "{\"email\":\"${EMAIL}\",\"password\":\"${PASSWORD}\"}" \
  | python3 -c 'import json,sys;print(json.load(sys.stdin)["access"])'
)

# 2. Опубликовать пост (multipart).
# Поля:
#   dish_name           — название блюда (обязательно).
#   description         — текст (до 2000 символов).
#   price               — число, рубли (decimal как строка тоже принимается).
#   rating              — 0..10 (см. settings MAX_REVIEW_RATING).
#   restaurant_name + restaurant_address — создают/находят ресторан;
#                         либо передайте restaurant_id для уже существующего.
#   uploaded_images     — файл (можно повторять для нескольких изображений).
#   tags_list           — строка тега (можно повторять; ≤50 символов).
curl --fail-with-body -sS -X POST "${BASE_URL}/posts/" \
  -H "Authorization: Bearer ${TOKEN}" \
  -F "dish_name=Цезарь с курицей" \
  -F "description=Свежий, листья хрустят, заправка не жирная." \
  -F "price=450" \
  -F "rating=5" \
  -F "restaurant_name=Демо-кафе" \
  -F "restaurant_address=ул. Примерная, 1" \
  -F "uploaded_images=@${IMAGE_PATH}" \
  -F "tags_list=салат" \
  -F "tags_list=обед"
