#!/usr/bin/env bash
# Подписаться / отписаться от пользователя.
#
# Эндпоинты: POST /api/v1/users/{id}/subscribe/   — подписаться (идемпотентный toggle).
#            DELETE /api/v1/users/{id}/subscribe/ — отписаться (204 без тела).
#
# Auth:      authenticated user (300 req/min).
# Замечание: путей /follow/ и /unfollow/ не существует. См. reference/users.md.
#            На себя подписаться нельзя — 400 {"error":"Нельзя подписаться на себя"}.
# См. conventions.md#toggle-semantics.

set -euo pipefail

BASE_URL="${BASE_URL:-https://foody.press/api/v1}"
EMAIL="${EMAIL:-test_user1@test.local}"
PASSWORD="${PASSWORD:-foodytest123}"
TARGET_USER_ID="${TARGET_USER_ID:-74}"   # test_user2 в проде

TOKEN=$(
  curl --fail-with-body -sS -X POST "${BASE_URL}/auth/token/" \
    -H 'Content-Type: application/json' \
    -d "{\"email\":\"${EMAIL}\",\"password\":\"${PASSWORD}\"}" \
  | python3 -c 'import json,sys;print(json.load(sys.stdin)["access"])'
)

echo "--- Подписка ---"
curl --fail-with-body -sS -X POST \
  "${BASE_URL}/users/${TARGET_USER_ID}/subscribe/" \
  -H "Authorization: Bearer ${TOKEN}"
echo

# Идемпотентность: повторный POST вернёт {"status":"followed","created":false}.
# Снять подписку — DELETE.
echo "--- Отписка ---"
curl --fail-with-body -sS -X DELETE \
  "${BASE_URL}/users/${TARGET_USER_ID}/subscribe/" \
  -H "Authorization: Bearer ${TOKEN}" \
  -w "HTTP %{http_code}\n"
