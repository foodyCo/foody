"""Опубликовать пост с фотографией.

Запуск:      IMAGE_PATH=./photo.jpg python3 publish-post.py
Зависимость: requests (`pip install requests`).
Эндпоинт:    POST /api/v1/posts/
Auth:        authenticated user (300 req/min). JWT обязателен.

ВАЖНО: ответ 201 возвращает пост со status="pending". До тех пор пока
модератор не выполнит POST /api/v1/moderation/{id}/approve/, пост
в общей ленте (GET /api/v1/posts/) не появится. См. conventions.md#post-lifecycle.

В конце печатает JSON-ответ в stdout (требование §3.4 пайплайна).
"""

import json
import os
import sys

import requests

BASE_URL = os.environ.get("BASE_URL", "https://foody.press/api/v1")
EMAIL = os.environ.get("EMAIL", "test_user1@test.local")
PASSWORD = os.environ.get("PASSWORD", "foodytest123")
IMAGE_PATH = os.environ.get("IMAGE_PATH", "./photo.jpg")


def login() -> str:
    resp = requests.post(
        f"{BASE_URL}/auth/token/",
        json={"email": EMAIL, "password": PASSWORD},
        timeout=10,
    )
    if resp.status_code != 200:
        sys.stderr.write(f"login failed: HTTP {resp.status_code} {resp.text}\n")
        sys.exit(1)
    return resp.json()["access"]


def publish(token: str) -> dict:
    if not os.path.isfile(IMAGE_PATH):
        sys.stderr.write(f"Файл фотографии не найден: {IMAGE_PATH}\n")
        sys.exit(1)

    # Поля: см. PostCreateSerializer.Meta.fields в backend/posts/serializers.py.
    data = [
        ("dish_name", "Цезарь с курицей"),
        ("description", "Свежий, листья хрустят, заправка не жирная."),
        ("price", "450"),
        ("rating", "5"),
        ("restaurant_name", "Демо-кафе"),
        ("restaurant_address", "ул. Примерная, 1"),
        # Повторяющиеся ключи дают список тегов.
        ("tags_list", "салат"),
        ("tags_list", "обед"),
    ]
    with open(IMAGE_PATH, "rb") as fh:
        files = [("uploaded_images", (os.path.basename(IMAGE_PATH), fh, "image/jpeg"))]
        resp = requests.post(
            f"{BASE_URL}/posts/",
            headers={"Authorization": f"Bearer {token}"},
            data=data,
            files=files,
            timeout=30,
        )
    if resp.status_code != 201:
        sys.stderr.write(f"publish failed: HTTP {resp.status_code} {resp.text}\n")
        sys.exit(1)
    return resp.json()


def main() -> None:
    token = login()
    post = publish(token)
    print(json.dumps(post, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
