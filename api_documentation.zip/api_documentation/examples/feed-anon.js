// Получить публичную ленту анонимно (без JWT).
//
// Запуск:   node feed-anon.js
// Эндпоинт: GET /api/v1/posts/
// Auth:     anon (60 req/min) — токен не нужен.
//
// В конце печатает JSON-ответ в stdout (требование §3.4 пайплайна:
// verify-loop Фазы 4 делает JSON-key diff против фактического curl-ответа).

const BASE_URL = process.env.BASE_URL || 'https://foody.press/api/v1';

async function main() {
  const url = `${BASE_URL}/posts/?page=1&page_size=5`;
  const response = await fetch(url, {
    headers: { Accept: 'application/json' },
  });

  if (!response.ok) {
    const body = await response.text();
    throw new Error(`HTTP ${response.status} ${response.statusText}: ${body}`);
  }

  const data = await response.json();
  console.log(JSON.stringify(data, null, 2));
}

main().catch((err) => {
  console.error(err.message);
  process.exit(1);
});
