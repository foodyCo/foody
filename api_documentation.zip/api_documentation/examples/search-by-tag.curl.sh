#!/usr/bin/env bash
# Поиск постов по тегу + пагинация.
#
# Эндпоинт: GET /api/v1/posts/
# Auth:     anon (60 req/min) — токен не требуется.
#
# Фильтры по тегам (см. conventions.md#filters):
#   ?tag_name=<имя>            — точное совпадение по имени (iexact), case-insensitive.
#   ?tag_id=1,2,3              — IN-фильтр по числовым id (запятыми, без пробелов).
#   ?search=<строка>           — полнотекстовый поиск по dish__name, restaurant__name,
#                                tags__name и категориям.
#
# Пагинация: PageNumberPagination, ?page=N&page_size=M (max 100).

set -euo pipefail

BASE_URL="${BASE_URL:-https://foody.press/api/v1}"
TAG_NAME="${TAG_NAME:-русская}"

# 1. Получить справочник тегов (не paginated, отдаётся массивом целиком).
echo "--- Tags index ---"
curl --fail-with-body -sS "${BASE_URL}/tags/" \
  -H 'Accept: application/json' \
  | python3 -c 'import json,sys;d=json.load(sys.stdin);print(f"всего тегов: {len(d)}; первые 5: {d[:5]}")'

echo

# 2. Найти посты по имени тега, страница 1.
echo "--- Posts with tag_name=${TAG_NAME} (page=1) ---"
curl --fail-with-body -sS \
  "${BASE_URL}/posts/?tag_name=${TAG_NAME}&page=1&page_size=5" \
  -H 'Accept: application/json'
