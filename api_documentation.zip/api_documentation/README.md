# Foody API — документация

REST API для социальной сети о ресторанных блюдах. Все эндпоинты опубликованы
под префиксом `/api/v1/`, отвечают JSON, авторизация — JWT (Bearer-токен).

| Среда | Базовый URL |
|---|---|
| Прод | `https://foody.press/api/v1` |
| Локально (Docker dev) | `http://localhost/api/v1` |

Машинно-читаемая схема и Swagger UI:

| Ресурс | URL |
|---|---|
| OpenAPI JSON | `https://foody.press/api/schema/` |
| Swagger UI | `https://foody.press/api/docs/` |

> Пути `/api/schema/` и `/api/docs/` подключены **без** префикса `/api/v1/`.

---

## С чего начать

1. Прочитайте [quickstart.md](quickstart.md) — 15-минутный путь от регистрации
   до публикации поста и его одобрения через модерацию.
2. Изучите [conventions.md](conventions.md) — пагинация, throttle, формат
   media-URL, фильтры, жизненный цикл поста, PII.
3. Освойте [auth.md](auth.md) — регистрация, JWT, refresh, staff-доступ.
4. Откройте конкретный ресурс в [reference/](reference/).
5. Держите под рукой [errors.md](errors.md) — два DRF-формата ошибок и
   полный реестр HTTP-кодов.

---

## Содержание

- [quickstart.md](quickstart.md) — пошаговый туториал
- [auth.md](auth.md) — аутентификация, JWT, регистрация, staff-доступ
- [conventions.md](conventions.md) — общие правила API (пагинация, throttle, фильтры, lifecycle, PII)
- [errors.md](errors.md) — HTTP-коды и формат тел ошибок
- [changelog.md](changelog.md) — версии и политика совместимости
- Reference:
  - [reference/users.md](reference/users.md) — пользователи, профили, подписки
  - [reference/posts.md](reference/posts.md) — посты, лайки, сохранения, комментарии
  - [reference/restaurants.md](reference/restaurants.md) — рестораны и блюда
  - [reference/categories.md](reference/categories.md) — категории и теги
  - [reference/moderation.md](reference/moderation.md) — очередь модерации
- Готовые примеры — `examples/` (curl + JS + Python для hero-сценариев,
  curl-only для остальных).

---

## Полная карта эндпоинтов

Иконки auth-уровня: 🔓 anon (без токена), 🔒 user (требуется JWT),
👮 staff (`is_staff=True`).

### Аутентификация

| Метод | Путь | Auth | Документация |
|---|---|---|---|
| POST | `/api/v1/auth/token/` | 🔓 | [auth.md#jwt-obtain](auth.md#jwt-obtain) |
| POST | `/api/v1/auth/token/refresh/` | 🔓 | [auth.md#jwt-refresh](auth.md#jwt-refresh) |

### Пользователи

| Метод | Путь | Auth | Документация |
|---|---|---|---|
| POST | `/api/v1/users/register/` | 🔓 | [auth.md#register](auth.md#register) |
| GET | `/api/v1/users/check-email/` | 🔓 | [auth.md#availability-checks](auth.md#availability-checks) |
| GET | `/api/v1/users/check-username/` | 🔓 | [auth.md#availability-checks](auth.md#availability-checks) |
| GET | `/api/v1/users/me/` | 🔒 | [reference/users.md](reference/users.md#получить-свой-профиль) |
| PATCH | `/api/v1/users/me/` | 🔒 | [reference/users.md](reference/users.md#обновить-свой-профиль) |
| DELETE | `/api/v1/users/me/` | 🔒 | [auth.md#account-delete](auth.md#account-delete) |
| GET | `/api/v1/users/{id}/` | 🔓 | [reference/users.md](reference/users.md#профиль-пользователя) |
| POST | `/api/v1/users/{id}/subscribe/` | 🔒 | [reference/users.md](reference/users.md#подписаться-на-пользователя) |
| DELETE | `/api/v1/users/{id}/subscribe/` | 🔒 | [reference/users.md](reference/users.md#отписаться-от-пользователя) |

### Посты

| Метод | Путь | Auth | Документация |
|---|---|---|---|
| GET | `/api/v1/posts/` | 🔓 | [reference/posts.md](reference/posts.md#список-постов-лента) |
| POST | `/api/v1/posts/` | 🔒 | [reference/posts.md](reference/posts.md#создать-пост) |
| GET | `/api/v1/posts/{id}/` | 🔓 | [reference/posts.md](reference/posts.md#получить-пост) |
| PATCH | `/api/v1/posts/{id}/` | 🔒 | [reference/posts.md](reference/posts.md#обновить-пост) |
| PUT | `/api/v1/posts/{id}/` | 🔒 | [reference/posts.md](reference/posts.md#обновить-пост) |
| DELETE | `/api/v1/posts/{id}/` | 🔒/👮 | [reference/posts.md](reference/posts.md#удалить-пост) |
| GET | `/api/v1/posts/my/` | 🔒 | [reference/posts.md](reference/posts.md#мои-посты) |
| GET | `/api/v1/posts/saved/` | 🔒 | [reference/posts.md](reference/posts.md#сохранённые-посты) |
| GET | `/api/v1/posts/user_posts/` | 🔓 | [reference/posts.md](reference/posts.md#посты-пользователя) |
| GET | `/api/v1/posts/following/` | 🔒 | [reference/posts.md](reference/posts.md#посты-подписок) |
| GET | `/api/v1/posts/liked/` | 🔒 | [reference/posts.md](reference/posts.md#понравившиеся-посты) |
| POST | `/api/v1/posts/{id}/like/` | 🔒 | [reference/posts.md](reference/posts.md#лайк-поста) |
| POST | `/api/v1/posts/{id}/save_post/` | 🔒 | [reference/posts.md](reference/posts.md#сохранение-поста) |
| GET | `/api/v1/posts/{id}/comments/` | 🔓 | [reference/posts.md](reference/posts.md#комментарии-к-посту) |
| POST | `/api/v1/posts/{id}/comments/` | 🔒 | [reference/posts.md](reference/posts.md#комментарии-к-посту) |
| DELETE | `/api/v1/posts/{id}/comments/{comment_pk}/` | 🔒/👮 | [reference/posts.md](reference/posts.md#удалить-комментарий) |
| POST | `/api/v1/comments/{id}/like/` | 🔒 | [reference/posts.md](reference/posts.md#лайк-комментария) |
| DELETE | `/api/v1/comments/{id}/like/` | 🔒 | [reference/posts.md](reference/posts.md#снять-лайк-с-комментария) |
| GET | `/api/v1/comments/likes/` | 🔒 | [reference/posts.md](reference/posts.md#batch-статус-лайков-комментариев) |

### Рестораны и блюда

| Метод | Путь | Auth | Документация |
|---|---|---|---|
| GET | `/api/v1/restaurants/` | 🔓 | [reference/restaurants.md](reference/restaurants.md#список-ресторанов) |
| GET | `/api/v1/restaurants/{id}/` | 🔓 | [reference/restaurants.md](reference/restaurants.md#детали-ресторана) |
| GET | `/api/v1/dishes/` | 🔓 | [reference/restaurants.md](reference/restaurants.md#список-блюд) |

### Категории и теги

| Метод | Путь | Auth | Документация |
|---|---|---|---|
| GET | `/api/v1/categories/` | 🔓 | [reference/categories.md](reference/categories.md#список-категорий) |
| POST | `/api/v1/categories/` | 👮 | [reference/categories.md](reference/categories.md#создать-категорию) |
| GET | `/api/v1/categories/{id}/` | 🔓 | [reference/categories.md](reference/categories.md#детальная-карточка-категории) |
| PATCH | `/api/v1/categories/{id}/` | 👮 | [reference/categories.md](reference/categories.md#обновить-категорию) |
| PUT | `/api/v1/categories/{id}/` | 👮 | [reference/categories.md](reference/categories.md#обновить-категорию) |
| DELETE | `/api/v1/categories/{id}/` | 👮 | [reference/categories.md](reference/categories.md#удалить-категорию) |
| GET | `/api/v1/categories/popular/` | 🔓 | [reference/categories.md](reference/categories.md#популярные-категории) |
| GET | `/api/v1/tags/` | 🔓 | [reference/categories.md](reference/categories.md#список-тегов) |
| GET | `/api/v1/tags/{id}/` | 🔓 | [reference/categories.md](reference/categories.md#детальная-карточка-тега) |

### Модерация (staff)

| Метод | Путь | Auth | Документация |
|---|---|---|---|
| GET | `/api/v1/moderation/` | 👮 | [reference/moderation.md](reference/moderation.md#список-постов-на-модерации) |
| GET | `/api/v1/moderation/{id}/` | 👮 | [reference/moderation.md](reference/moderation.md#детали-поста-из-очереди) |
| POST | `/api/v1/moderation/{id}/approve/` | 👮 | [reference/moderation.md](reference/moderation.md#одобрить-пост-) |
| POST | `/api/v1/moderation/{id}/reject/` | 👮 | [reference/moderation.md](reference/moderation.md#отклонить-пост-) |

---

## Соглашения

- Авторизация: `Authorization: Bearer <access>` — см. [auth.md#header](auth.md#header).
- Пагинация: `{count, next, previous, results}` — см. [conventions.md#pagination](conventions.md#pagination).
- Throttle: `anon 60/min`, `user 300/min`, `login 10/min` — см. [conventions.md#throttle](conventions.md#throttle).
- Медиа-URL приходят относительными (`/media/...`) — см. [conventions.md#media-urls](conventions.md#media-urls).
- Формат ошибок: `{detail: "..."}` или `{field: ["..."]}` — см. [errors.md#drf-formats](errors.md#drf-formats).
