# Соглашения API

Этот документ — единый источник правды по общим правилам игры в Foody API.
Reference-файлы ссылаются на якоря из этого файла; здесь правила пишутся один раз.

---

## Базовый URL и версия {#base-url}

| Среда | Базовый URL |
|---|---|
| Прод | `https://foody.press/api/v1` |
| Локально (Docker dev) | `http://localhost/api/v1` |

Все эндпоинты Foody API ниже `/api/v1/`. Версия API — часть пути; при выходе
несовместимой версии появится параллельный префикс `/api/v2/`. Пока в проекте
существует только `v1`.

OpenAPI-схема и Swagger UI:

| Ресурс | URL |
|---|---|
| OpenAPI JSON | `https://foody.press/api/schema/` |
| Swagger UI | `https://foody.press/api/docs/` |

> **NB:** Пути схемы и docs **без** префикса `/api/v1/` (drf-spectacular подключён
> на уровне `config/urls.py` отдельно). Это известная особенность маршрутизации.

В примерах далее используется переменная окружения:

```bash
export BASE_URL=https://foody.press/api/v1
```

---

## Заголовки запроса

| Заголовок | Когда обязателен | Значение |
|---|---|---|
| `Authorization` | для всех 🔒 user / 👮 staff эндпоинтов | `Bearer <access_token>` (см. [auth.md#header](auth.md#header)) |
| `Content-Type` | для POST/PATCH/PUT c JSON-телом | `application/json` |
| `Content-Type` | для `POST /posts/` с загрузкой фото | `multipart/form-data` (curl выставит сам при `-F`) |
| `Accept` | по умолчанию `application/json` | DRF умеет также `text/html` (browsable API), но это для отладки |

---

## Пагинация {#pagination}

По умолчанию `rest_framework.pagination.PageNumberPagination` с `PAGE_SIZE = 20`
(`REST_FRAMEWORK.PAGE_SIZE`, env-параметр `PAGE_SIZE`). Любой paginated-список
возвращает фиксированную обёртку:

```json
{
  "count": 5,
  "next": null,
  "previous": null,
  "results": [ ... ]
}
```

| Поле | Тип | Описание |
|---|---|---|
| `count` | int | Полное число записей в выборке (не на текущей странице) |
| `next` | string \| null | Полный URL следующей страницы или `null` |
| `previous` | string \| null | Полный URL предыдущей страницы или `null` |
| `results` | array | Записи на текущей странице |

### Query-параметры пагинации

| Параметр | Дефолт | Применимость |
|---|---|---|
| `page` | 1 | везде, где есть пагинация |
| `page_size` | `PAGE_SIZE` (20) | только эндпоинты с кастомным классом (см. таблицу ниже) |

### Классы пагинации по эндпоинтам

| Класс | Эндпоинты | `page_size` | `page_size_query_param` | `max_page_size` |
|---|---|---|---|---|
| `PageNumberPagination` (default) | `/restaurants/`, `/dishes/`, `/categories/`, `/users/{id}/` и т.п. | 20 | — (нельзя менять через query) | — |
| `StandardResultsPagePagination` | `/posts/*` (включая `my/`, `saved/`, `user_posts/`, `following/`, `liked/`, `{id}/comments/`) | 20 | `page_size` | 100 |
| `ModerationPagination` | `/moderation/` | 10 | `page_size` | — |

### Эндпоинты без пагинации

`GET /api/v1/tags/` отдаёт массив целиком (`pagination_class = None`),
**не** обёрнутый в `{count, next, previous, results}`. То же — для
`GET /api/v1/categories/popular/` (там просто массив с clamp `limit`∈[1..50]).

### Ответ при невалидной странице

`?page=99999` или `?page=abc` → 404 (формат — `{detail: ...}`, см.
[errors.md#404](errors.md#404)):

```json
{"detail": "Неправильная страница"}
```

---

## Throttle (rate limiting) {#throttle}

Лимиты заданы в `REST_FRAMEWORK.DEFAULT_THROTTLE_RATES`
(`backend/config/settings.py:213-217`). Foody использует три scope'a:

| Scope | Лимит | Кому считается | Применяется |
|---|---|---|---|
| `anon` | **60 / минуту** | по IP | все анонимные запросы (`AnonRateThrottle`) |
| `user` | **300 / минуту** | по `user.id` | все авторизованные запросы (`UserRateThrottle`) |
| `login` | **10 / минуту** | по IP (наследует `AnonRateThrottle`) | только `POST /auth/token/` и `POST /auth/token/refresh/` |

> `login` scope считается **по IP** даже если запрос содержит валидный refresh-токен
> — это намеренно, чтобы один источник не мог брутить разные аккаунты. Подробнее
> — `backend/config/urls.py:16-23`.

### Поведение при превышении лимита

Сервер возвращает **HTTP 429 Too Many Requests** с заголовком `Retry-After`
(целое число секунд) и телом в формате `{detail: ...}`:

```http
HTTP/2 429
retry-after: 8
content-type: application/json

{"detail": "Запрос был проигнорирован. Expected available in 8 seconds."}
```

Клиент обязан спать `Retry-After` секунд и сделать retry **не раньше** этого
интервала. Тело и заголовок — см. [errors.md#429](errors.md#429).

### Подсказки для интеграторов

- Для bulk-скриптов с anon-доступом держите паузу **≥ 1.2 секунды** между
  запросами — это даёт фактический потолок ~50/min при лимите 60/min и страхует
  от случайного 429.
- Авторизованным клиентам (300/min) пауза не нужна, но превышение всё ещё
  даёт 429.
- На `/auth/token/*` ретраев в цикле быть не должно — после 10 неудачных логинов
  с одного IP вы будете надёжно заблокированы.

---

## Media-URL'ы {#media-urls}

Все медиа-поля (`avatar` у пользователей, `images[].image` у постов) возвращаются
как **относительные** пути от корня сайта, **без хоста**:

```json
{
  "avatar": "/media/avatars/u142/avatar.webp",
  "images": [
    {"id": 11, "image": "/media/post_photos/p98/0001.jpg"}
  ]
}
```

Клиент **обязан** склеивать с публичной точкой сайта **без `/api/v1`**:

```js
const fullUrl = `https://foody.press${avatar}`;   // https://foody.press/media/...
```

Caddy раздаёт `/media/*` напрямую (см. CLAUDE.md «Request Flow»). Никаких
sign-URL'ов, кэш-busterов или CDN-префиксов в API не появляется.

> `null` в поле `avatar` значит «аватар не загружен» — фронт обязан показать
> placeholder.

### Лимит размера multipart-запросов

Caddy (reverse-proxy) ограничивает размер запроса в **30 MiB** на запрос (см.
`infra/caddy/Caddyfile`). При попытке загрузить большее тело клиент получит
413 от Caddy — **до** того, как запрос дойдёт до Django. Это влияет на
`POST /posts/` (загрузка фото блюда) и `PATCH /users/me/` (смена аватара).

---

## PII и видимость полей {#pii}

Сериализатор `UserSerializer.to_representation` (`backend/users/serializers.py`)
скрывает чувствительные поля от **не-владельца** профиля:

| Поле | На своём `/users/me/` | На чужом `/users/{id}/` (anon или другой юзер) | На чужом `/users/{id}/` (staff-зритель) |
|---|---|---|---|
| `id`, `username`, `full_name` | видно | видно | видно |
| `avatar`, `bio_text`, `city` | видно | видно | видно |
| `posts_count`, `followers_count`, `following_count` | видно | видно | видно |
| `is_following` | всегда `false` для self | реальное значение | реальное значение |
| `email` | видно | **скрыто** | **скрыто** |
| `birth_date` | видно | **скрыто** | **скрыто** |
| `date_joined` | видно | **скрыто** | **скрыто** |
| `is_staff` | видно | **скрыто** | видно |

«Скрыто» = ключ **удалён** из JSON-ответа (не `null`).

Это контракт: интеграция, ожидающая `email` на чужом профиле, должна обрабатывать
его отсутствие, а не подмену.

---

## Жизненный цикл поста {#post-lifecycle}

Каждый `Post` проходит обязательную модерацию:

```
   pending  ──approve──▶  approved   (видно всем, попадает в /posts/)
      │
      └─reject─────────▶  rejected   (видит только автор, не попадает в /posts/)
```

| Состояние | Кто видит в `GET /posts/` | Кто видит в `GET /posts/{id}/` |
|---|---|---|
| `pending` | никто | только автор; staff-модератор — через `/moderation/{id}/` |
| `approved` | все (включая anon) | все |
| `rejected` | никто | только автор (поле `rejection_reason`); staff — через admin |

### Жёсткие правила

1. **Автор не может лайкать собственный pending/rejected пост** — 403 (см. [errors.md#403](errors.md#403)).
   Это защита от накрутки скрытого контента.
2. **`PATCH /posts/{id}/` автором сбрасывает статус в `pending`** и обнуляет
   `moderated_by` / `moderated_at`. После любой правки пост уходит на повторную
   модерацию.
3. **`POST /moderation/{id}/approve/` после `reject`** возвращает 404 — `queryset`
   модерации фильтрует только `status=pending`. Восстановить отклонённый пост
   можно только через Django admin.
4. Anon, заходящий на профиль автора через `/posts/user_posts/?user_id=N`,
   получает **только approved** посты этого автора. Сам автор через
   `/posts/my/` получает все три статуса.

См. также [reference/moderation.md](reference/moderation.md).

---

## Идемпотентные toggle-эндпоинты {#toggle-semantics}

Foody использует один и тот же паттерн для лайков, сохранений и подписок:
**POST переключает** состояние и возвращает **новое** значение флага.

| Эндпоинт | Тело запроса | Ответ |
|---|---|---|
| `POST /posts/{id}/like/` | пустое | `{"liked": true}` или `{"liked": false}` (после переключения) |
| `POST /posts/{id}/save_post/` | пустое | `{"saved": true}` или `{"saved": false}` |
| `POST /comments/{id}/like/` | пустое | `{"liked": true, "comment_id": 42}` |
| `POST /users/{id}/subscribe/` | пустое | `{"status": "followed", "created": true}` или `{"status": "followed", "created": false}` |

### Правила

- Тело запроса всегда **пустое**. Передача `{"like": true}` ничего не меняет.
- Повторный POST переключает обратно. `select_for_update` сериализует
  параллельные клики одного юзера, повторные клики не дают «двойных» инкрементов.
- Снятие подписки и снятие лайка комментария — отдельные DELETE:
  - `DELETE /users/{id}/subscribe/` → 204
  - `DELETE /comments/{id}/like/` → 204 (явное снятие, не toggle)
- В `POST /users/{id}/subscribe/` поле `created` отвечает на вопрос «эта подписка
  только что появилась?». `created=false` означает, что запись уже была. Сама
  подписка после успешного POST всегда есть.
- Подписаться на себя нельзя — 400 `{"error": "Нельзя подписаться на себя"}`.

---

## Фильтры, поиск, сортировка {#filters}

Foody использует комбинацию `DjangoFilterBackend` + `SearchFilter` + `OrderingFilter`
(`REST_FRAMEWORK.DEFAULT_FILTER_BACKENDS`). Конкретные имена параметров и поля для
каждого ресурса — в `reference/<resource>.md`. Общие правила:

### Фильтры на `/posts/` (через `PostFilterSet`)

| Параметр | Тип | Поведение |
|---|---|---|
| `tag_id` | `1,2,3` (CSV) | `IN`-фильтр по `tags.id` |
| `tag_name` | string | `iexact` по `tags.name` |
| `author`, `user_id`, `user` | int | по `author.id` (три алиаса для совместимости) |
| `restaurant_id` | int | по `restaurant.id` |
| `category_id` | int | по категории через `dish.category` ИЛИ `restaurant.categories` |
| `city` | string | `icontains` по `restaurant.address` |
| `price_min` | number ≥ 0 | нижняя граница `price` (**именно `price_min`**, не `min_price`) |
| `price_max` | number ≥ 0 | верхняя граница `price` |

Отрицательные значения `price_min/max` → 400.

### Сортировка через `?ordering=`

Поддержанные поля: `created_at`, `statistics__rating`, `statistics__likes_count`,
`price`. Префикс `-` — desc. По умолчанию `-created_at, -id` (tie-breaker по id
для стабильной пагинации).

```
GET /posts/?ordering=-statistics__rating
GET /posts/?ordering=price
```

### Поиск через `?search=`

`SearchFilter` ищет по `dish.name`, `restaurant.name`, `tags.name` и связанным
категориям. Регистронезависимый, частичное совпадение.

```
GET /posts/?search=рамен
```

### Комбинация фильтров

Параметры комбинируются через AND:

```
GET /posts/?tag_id=1,2&price_min=300&price_max=1500&ordering=-statistics__rating
```

---

## Язык ответов {#language}

`LANGUAGE_CODE = 'ru'`, `USE_I18N = True`. По умолчанию DRF возвращает
системные сообщения **на русском**:

- `"Учетные данные не были предоставлены."` — 401 без токена
- `"У вас недостаточно прав для выполнения данного действия."` — 403
- `"Неправильная страница"` — 404 на невалидную страницу пагинации
- `"Запрос был проигнорирован. Expected available in N seconds."` — 429

Отдельные тексты остаются **на английском**, потому что приходят из `simplejwt`,
который не переведён:

- `"No active account found with the given credentials"` — неверный пароль на `/auth/token/`
- `"Token is invalid or expired"` — невалидный refresh
- `"Authorization header must contain two space-delimited values"` — кривой Bearer-заголовок

Полный реестр текстов и их кодов — в [errors.md](errors.md).
