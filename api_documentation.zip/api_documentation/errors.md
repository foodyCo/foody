# Ошибки

Полный справочник кодов ответа Foody API. Все примеры тел сняты с прода
(`https://foody.press/api/v1/...`) на 2026-05-20 и не выдуманы.

> Для понимания структуры ошибок начните с раздела [DRF-форматы](#drf-formats) —
> там объяснены **два** взаимоисключающих стиля JSON-ответа, которые DRF
> использует для разных классов ошибок.

---

## Формат ответов DRF {#drf-formats}

Django REST Framework возвращает ошибки в **двух различных форматах**, в
зависимости от того, что их сгенерировало. Клиент обязан уметь обрабатывать оба.

| Формат | Когда | Источник | Пример |
|---|---|---|---|
| **`{detail: "..."}`** | один общий текст ошибки | `APIException`, permissions, throttle, JWT-валидация, `get_object_or_404` | `{"detail": "Учетные данные не были предоставлены."}` |
| **`{field: ["..."], ...}`** | per-field ошибки валидации | `ModelSerializer.is_valid()` | `{"email": ["Введите правильный адрес электронной почты."]}` |

Дополнительно встречаются:

- `{"non_field_errors": ["..."]}` — ошибки валидации, не привязанные к
  конкретному полю (например, кастомные `validate()` в сериализаторах).
- `{"error": "..."}` — нестандартное поле, которое возвращают **несколько кастомных
  view'ов Foody** (вне DRF-обработки исключений):
  - `GET /users/check-email/`, `GET /users/check-username/` при пустом параметре
    (`{"error": "email is required"}` / `{"error": "username is required"}`)
  - `POST /users/{id}/subscribe/` при попытке подписаться на себя
    (`{"error": "Нельзя подписаться на себя"}`)
- `{"detail": "...", "code": "..."}` — обогащённый формат от `simplejwt`
  (например `{"detail": "Token is invalid or expired", "code": "token_not_valid"}`).

### Сводная таблица: где какой формат

| HTTP | Формат | Эндпоинты-примеры |
|---|---|---|
| 400 (валидация сериализатора) | `{field: ["..."]}` | `POST /users/register/`, `PATCH /users/me/`, `POST /posts/` |
| 400 (бизнес-правило) | `{error: "..."}` или `{detail: "..."}` | `POST /users/{id}/subscribe/` (self), `GET /users/check-email/` (нет параметра) |
| 401 | `{detail: "..."}` | все защищённые эндпоинты |
| 403 | `{detail: "..."}` | permissions, lifecycle-запреты |
| 404 | `{detail: "..."}` | DRF `get_object_or_404`, невалидная страница |
| 429 | `{detail: "..."}` + заголовок `Retry-After` | все эндпоинты при превышении throttle |

---

## 400 Bad Request {#400}

Невалидные данные клиента — два подтипа.

### Per-field валидация (`ModelSerializer.is_valid()`)

`POST /api/v1/users/register/` с заведомо плохими данными:

```http
POST /api/v1/users/register/
Content-Type: application/json

{"username":"a","email":"notanemail","password":"123","password_confirm":"456"}
```

```http
HTTP/2 400
content-type: application/json

{
  "email": ["Введите правильный адрес электронной почты."],
  "password": [
    "Введённый пароль слишком короткий. Он должен состоять из как минимум 8 символов.",
    "Введённый пароль слишком широко распространён.",
    "Введённый пароль состоит только из цифр."
  ],
  "city": ["Обязательное поле."]
}
```

> Поле может содержать **массив** нескольких ошибок одновременно (как `password`
> выше). Парсер клиента должен показывать все, не только первую.

Дубликат уникального поля (после `IntegrityError` race-fix):

```json
{
  "username": ["user с таким username уже существует."],
  "email": ["user с таким email уже существует."]
}
```

### Бизнес-правило (кастомный view)

`POST /api/v1/users/{me_id}/subscribe/` от самого себя:

```json
{"error": "Нельзя подписаться на себя"}
```

`GET /api/v1/users/check-email/` без `?email=...`:

```json
{"error": "email is required"}
```

---

## 401 Unauthorized {#401}

Токен отсутствует, истёк или поломан. Всегда `{detail: ...}`, иногда с `code`.

### Нет заголовка Authorization

```http
GET /api/v1/users/me/
```

```json
{"detail": "Учетные данные не были предоставлены."}
```

### Невалидный access-токен

```json
{
  "detail": "Данный токен недействителен для любого типа токена",
  "code": "token_not_valid"
}
```

### Кривой Bearer-заголовок (`Authorization: Bearer` без токена, лишние пробелы)

```json
{
  "detail": "Authorization header must contain two space-delimited values",
  "code": "bad_authorization_header"
}
```

### Неверный пароль на `/auth/token/`

Текст из `simplejwt`, **не переведён** (см. [conventions.md#language](conventions.md#language)):

```json
{"detail": "No active account found with the given credentials"}
```

### Невалидный/истёкший refresh-токен

```json
{
  "detail": "Token is invalid or expired",
  "code": "token_not_valid"
}
```

---

## 403 Forbidden {#403}

Токен валиден, но прав на действие не хватает.

### Не staff на staff-эндпоинте

`GET /api/v1/moderation/` от обычного пользователя:

```json
{"detail": "У вас недостаточно прав для выполнения данного действия."}
```

### Лайк собственного pending/rejected поста

`POST /api/v1/posts/{id}/like/` автором своего же не-approved поста:

```json
{"detail": "Нельзя лайкать собственный пост до одобрения модератором."}
```

### Удаление чужого комментария

`DELETE /api/v1/posts/{post_id}/comments/{comment_id}/` не-автором и не-staff:

```json
{"detail": "У вас недостаточно прав для выполнения данного действия."}
```

---

## 404 Not Found {#404}

Объект не существует или эндпоинт — несуществующий путь.

### Объект отсутствует (DRF `get_object_or_404`)

```json
{"detail": "No Post matches the given query."}
```

```json
{"detail": "No User matches the given query."}
```

### Невалидная страница пагинации

`GET /api/v1/posts/?page=99999` или `?page=abc`:

```json
{"detail": "Неправильная страница"}
```

### Известные несуществующие пути

| Запрос | Что происходит |
|---|---|
| `POST /api/v1/users/{id}/follow/` | 404 (правильный путь — `/users/{id}/subscribe/`, см. [reference/users.md](reference/users.md)) |
| `POST /api/v1/users/{id}/unfollow/` | 404 (правильный путь — `DELETE /users/{id}/subscribe/`) |
| `GET /api/v1/users/by-username/{u}/` | 404 (эндпоинта не существует, lookup только по `int:user_id`) |
| `POST /api/v1/moderation/{id}/approve/` после `reject` | 404 (`queryset` фильтрует `status=pending`) |

> При попадании на не-DRF URL (например, опечатка `/api/v1/postss/`) ответ может
> прийти от Caddy как HTML — это normal Django/Caddy fallback на `Not Found`.
> DRF-формат `{detail: ...}` гарантирован только для путей внутри API.

---

## 422 Unprocessable Entity {#422}

Foody **не возвращает** 422. Все ошибки валидации сериализатора отдаются как 400
(см. [#400](#400)). drf-spectacular иногда декларирует 422 в OpenAPI для
эндпоинтов с per-field валидацией, но это расхождение схемы с фактическим
поведением — фактический код всегда 400.

> Если когда-либо ваш клиент получит 422 от Foody — это новый эндпоинт или
> внешний прокси. На текущий момент это off-spec.

---

## 429 Too Many Requests {#429}

Превышение throttle (см. [conventions.md#throttle](conventions.md#throttle) —
лимиты `anon 60/min`, `user 300/min`, `login 10/min`).

### Реальный ответ с прода (`POST /auth/token/` после 10+ попыток)

```http
HTTP/2 429
allow: POST, OPTIONS
content-type: application/json
retry-after: 8

{"detail": "Запрос был проигнорирован. Expected available in 8 seconds."}
```

| Заголовок | Тип | Значение |
|---|---|---|
| `retry-after` | int | Секунд до сброса лимита. **Обязательное** для 429 от DRF. |

### Поведение клиента

1. Прочитать заголовок `Retry-After`.
2. Подождать **ровно** это число секунд.
3. Повторить запрос **не более одного раза**.
4. Если повторный запрос снова 429 — это уже не jitter, увеличить паузу или
   разбираться с распределением нагрузки.

Псевдокод:

```python
import time, requests

resp = requests.post(f"{BASE_URL}/auth/token/", json=creds)
if resp.status_code == 429:
    delay = int(resp.headers.get("Retry-After", "60"))
    time.sleep(delay)
    resp = requests.post(f"{BASE_URL}/auth/token/", json=creds)
```

### Гранулярность

- `anon` (60/min) — общий buckets для всех эндпоинтов, отвечающих анонимам.
- `user` (300/min) — общий bucket для всех авторизованных эндпоинтов.
- `login` (10/min) — отдельный bucket **только** для `/auth/token/` и
  `/auth/token/refresh/`. Считается **по IP**, не по аккаунту, даже на refresh.

---

## 500 Internal Server Error {#500}

В норме клиент не должен получать 500. Если получил — это баг бэкенда:

- ошибка в коде view'а
- проблема с БД / кэшем / Celery
- неожиданный формат входных данных, не отловленный сериализатором

Формат тела не гарантирован: может быть `{detail: "..."}`, HTML-страница Django
debug (если кейс попал на dev-инстанс с `DEBUG=True`) или пустое тело.

Если 500 воспроизводится — приложите к багу:

1. Метод, путь, тело запроса
2. Заголовки (без значения `Authorization`)
3. Полный ответ с тайм-стампом

---

## Сводный реестр текстов

| HTTP | `detail`/`error` | Когда |
|---|---|---|
| 400 | `"Нельзя подписаться на себя"` (в `error`) | `POST /users/{me}/subscribe/` |
| 400 | `"email is required"` (в `error`) | `GET /users/check-email/` без параметра |
| 400 | `"username is required"` (в `error`) | `GET /users/check-username/` без параметра |
| 400 | per-field на русском | DRF-валидация любого сериализатора |
| 401 | `"Учетные данные не были предоставлены."` | защищённый эндпоинт без токена |
| 401 | `"No active account found with the given credentials"` | `/auth/token/` неверный пароль |
| 401 | `"Token is invalid or expired"` (+ `code: "token_not_valid"`) | невалидный JWT |
| 401 | `"Authorization header must contain two space-delimited values"` (+ `code: "bad_authorization_header"`) | кривой Bearer-заголовок |
| 403 | `"У вас недостаточно прав для выполнения данного действия."` | permission denied |
| 403 | `"Нельзя лайкать собственный пост до одобрения модератором."` | автор → POST like на свой pending/rejected |
| 404 | `"No <Model> matches the given query."` | объект не найден |
| 404 | `"Неправильная страница"` | невалидный `?page=` |
| 429 | `"Запрос был проигнорирован. Expected available in N seconds."` | throttle (любой scope) |
