# Moderation

Очередь постов, ожидающих модерации. Все эндпоинты доступны **только** пользователям с флагом `is_staff=True`. Жизненный цикл поста (`pending → approved | rejected`) описан в [conventions.md#post-lifecycle](../conventions.md#post-lifecycle).

## Эндпоинты

| Метод | Путь | Auth | Throttle | Описание |
|---|---|---|---|---|
| GET | `/api/v1/moderation/` | 👮 staff | 300/min | Список постов в статусе `pending` |
| GET | `/api/v1/moderation/{id}/` | 👮 staff | 300/min | Детали одного поста из очереди |
| POST | `/api/v1/moderation/{id}/approve/` | 👮 staff | 300/min | Одобрить пост |
| POST | `/api/v1/moderation/{id}/reject/` | 👮 staff | 300/min | Отклонить пост |

---

## Список постов на модерации

`GET /api/v1/moderation/`

**Auth:** 👮 staff
**Throttle:** 300/min

### Описание

Возвращает paginated список постов со статусом `pending`, отсортированный по дате создания (старые — первыми). Только посты, ещё ожидающие решения модератора; уже одобренные и отклонённые здесь не отображаются.

Пагинация использует класс `ModerationPagination` с `page_size=10` (отличается от стандартного 20). Поддерживается параметр `?page_size=N`, максимум не ограничен явно. Подробнее о пагинации: [conventions.md#pagination](../conventions.md#pagination).

### Query-параметры

| Параметр | Тип | Required | Default | Описание |
|---|---|---|---|---|
| `page` | integer | нет | 1 | Номер страницы |
| `page_size` | integer | нет | 10 | Размер страницы |

### Ответы

**200 OK**

```json
{
  "count": 2,
  "next": null,
  "previous": null,
  "results": [
    {
      "id": 201,
      "user": {
        "id": 12,
        "username": "test_user1",
        "full_name": "Test User One",
        "avatar": null,
        "is_following": false
      },
      "restaurant": 45,
      "restaurant_name": "Солнышко",
      "restaurant_address": "Крупская 35",
      "dish": 88,
      "dish_name": "Борщ",
      "description": "Отличный борщ, рекомендую.",
      "price": "350.00",
      "created_at": "2026-05-20T14:00:00.000000Z",
      "images": [
        {
          "id": 102,
          "image": "/media/post_images/borsch.jpg",
          "uploaded_at": "2026-05-20T14:00:00.123456Z"
        }
      ],
      "statistics": {
        "likes_count": 0,
        "saves_count": 0,
        "comments_count": 0,
        "rating": 0.0
      },
      "tags": [
        {
          "id": 5,
          "name": "суп"
        }
      ],
      "categories": [
        {
          "id": 3,
          "name": "Русская кухня",
          "icon": "🍲",
          "color": "#E74C3C",
          "mode": "dishes"
        }
      ],
      "is_liked": false,
      "is_saved": false,
      "status": "pending",
      "rejection_reason": null
    }
  ]
}
```

**401 Unauthorized** — токен отсутствует или невалиден.

```json
{"detail": "Учетные данные не были предоставлены."}
```

**403 Forbidden** — пользователь аутентифицирован, но `is_staff=False`.

```json
{"detail": "У вас недостаточно прав для выполнения данного действия."}
```

Подробнее о форматах ошибок: [errors.md#403](../errors.md#403), [errors.md#drf-formats](../errors.md#drf-formats).

### Пример

```bash
export BASE_URL=https://foody.press/api/v1
export TOKEN=<staff_access_token>  # см. auth.md#staff-access

curl -X GET "${BASE_URL}/moderation/?page=1&page_size=10" \
  -H "Authorization: Bearer $TOKEN"
```

---

## Детали поста из очереди

`GET /api/v1/moderation/{id}/`

**Auth:** 👮 staff
**Throttle:** 300/min

### Описание

Возвращает полный объект поста из очереди модерации по его идентификатору. Если пост с данным `id` существует, но уже не находится в статусе `pending` (т.е. уже одобрен или отклонён), эндпоинт вернёт 404 — кверисет жёстко фильтрует `status=pending`.

### Параметры пути

| Параметр | Тип | Описание |
|---|---|---|
| `id` | integer | Идентификатор поста |

### Ответы

**200 OK** — структура объекта идентична одному элементу из `results` в списке модерации (см. выше).

**401 Unauthorized** — токен отсутствует или невалиден.

**403 Forbidden** — пользователь не является сотрудником (`is_staff=False`).

**404 Not Found** — пост не найден или не находится в статусе `pending`.

```json
{"detail": "No Post matches the given query."}
```

### Пример

```bash
export BASE_URL=https://foody.press/api/v1
export TOKEN=<staff_access_token>
export POST_ID=201

curl -X GET "${BASE_URL}/moderation/${POST_ID}/" \
  -H "Authorization: Bearer $TOKEN"
```

### Замечания

Нельзя получить через этот эндпоинт уже одобренный или отклонённый пост: кверисет ограничен `status=pending`. Это поведение задокументировано в [conventions.md#post-lifecycle](../conventions.md#post-lifecycle).

---

## Одобрить пост 👮

`POST /api/v1/moderation/{id}/approve/`

**Auth:** 👮 staff
**Throttle:** 300/min

### Описание

Переводит пост из статуса `pending` в `approved`. Фиксирует `moderated_by` (текущий пользователь) и `moderated_at` (текущее время UTC). После одобрения пост становится виден в публичной ленте `GET /api/v1/posts/`.

Тело запроса не требуется.

### Параметры пути

| Параметр | Тип | Описание |
|---|---|---|
| `id` | integer | Идентификатор поста |

### Ответы

**200 OK**

```json
{"status": "approved"}
```

**401 Unauthorized** — токен отсутствует или невалиден.

**403 Forbidden** — пользователь не является сотрудником.

**404 Not Found** — пост не найден или уже не в статусе `pending`. Попытка одобрить ранее отклонённый пост через этот эндпоинт невозможна — возвращается 404.

```json
{"detail": "No Post matches the given query."}
```

### Пример

```bash
export BASE_URL=https://foody.press/api/v1
export TOKEN=<staff_access_token>
export POST_ID=201

curl -X POST "${BASE_URL}/moderation/${POST_ID}/approve/" \
  -H "Authorization: Bearer $TOKEN"
```

### Замечания

Восстановить отклонённый пост через `approve/` невозможно: кверисет возвращает только посты со статусом `pending`. Для изменения статуса уже обработанного поста используйте Django admin.

---

## Отклонить пост 👮

`POST /api/v1/moderation/{id}/reject/`

**Auth:** 👮 staff
**Throttle:** 300/min

### Описание

Переводит пост из статуса `pending` в `rejected`. Принимает опциональное поле `rejection_reason` с текстовым объяснением отказа. Фиксирует `moderated_by` и `moderated_at`. Отклонённый пост остаётся видим владельцу через `GET /api/v1/posts/{id}/` и `GET /api/v1/posts/my/`, но не появляется в публичной ленте.

### Параметры пути

| Параметр | Тип | Описание |
|---|---|---|
| `id` | integer | Идентификатор поста |

### Тело запроса

```json
{
  "rejection_reason": "Фотография не соответствует блюду."
}
```

| Поле | Тип | Required | Описание |
|---|---|---|---|
| `rejection_reason` | string | нет | Причина отказа. Если не передано, сохраняется пустая строка. |

### Ответы

**200 OK**

```json
{"status": "rejected"}
```

**401 Unauthorized** — токен отсутствует или невалиден.

**403 Forbidden** — пользователь не является сотрудником.

**404 Not Found** — пост не найден или не в статусе `pending`.

```json
{"detail": "No Post matches the given query."}
```

### Пример

```bash
export BASE_URL=https://foody.press/api/v1
export TOKEN=<staff_access_token>
export POST_ID=201

curl -X POST "${BASE_URL}/moderation/${POST_ID}/reject/" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"rejection_reason": "Фотография не соответствует блюду."}'
```

### Замечания

Поле `rejection_reason` опциональное — можно отклонить пост без объяснения (передать пустой объект `{}` или не передавать тело вовсе). Повторное отклонение уже отклонённого поста вернёт 404 по той же причине, что и `approve/`.
