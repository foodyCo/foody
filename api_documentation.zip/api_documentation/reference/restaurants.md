# Restaurants

Справочник ресторанов и блюд Foody. Все эндпоинты доступны анонимно — данные нужны для страниц ресторана и формы создания поста.

## Эндпоинты

| Метод | Путь | Auth | Throttle | Описание |
|---|---|---|---|---|
| GET | `/api/v1/restaurants/` | 🔓 anon | 60/min | Список ресторанов (paginated) |
| GET | `/api/v1/restaurants/{id}/` | 🔓 anon | 60/min | Детали ресторана |
| GET | `/api/v1/dishes/` | 🔓 anon | 60/min | Список блюд (опционально — по ресторану) |

---

## Список ресторанов

`GET /api/v1/restaurants/`

**Auth:** 🔓 anon  
**Throttle:** 60/min  
**Tags:** restaurants

### Описание

Возвращает постраничный список всех ресторанов, упорядоченных по алфавиту. Используется при создании поста (поиск существующего ресторана) и на странице поиска.

Поддерживает полнотекстовый поиск по полю `name` через параметр `?search=`. Пагинация — стандартная `PageNumberPagination` с `page_size=20`; параметр `?page_size=` **не поддерживается**, регулировать страницу можно только через `?page=N`.

Подробнее о пагинации — см. [conventions.md#pagination](../conventions.md#pagination).

### Query-параметры

| Параметр | Тип | Required | Default | Описание |
|---|---|---|---|---|
| `page` | integer | Нет | 1 | Номер страницы |
| `search` | string | Нет | — | Полнотекстовый поиск по `name` (регистронезависимо) |

### Ответы

**200 OK**

```json
{
  "count": 67,
  "next": "https://foody.press/api/v1/restaurants/?page=2",
  "previous": null,
  "results": [
    {
      "id": 59,
      "name": "Mr.Bull",
      "address": "Цветной бульвар, 9",
      "categories": []
    },
    {
      "id": 51,
      "name": "Каферация",
      "address": "Тверская, 14",
      "categories": []
    }
  ]
}
```

**429 Too Many Requests** — превышен лимит 60 запросов/мин. Подробнее — [conventions.md#throttle](../conventions.md#throttle).

### Пример

```bash
export BASE_URL=https://foody.press/api/v1

# Все рестораны (первая страница)
curl -X GET "$BASE_URL/restaurants/"

# Поиск ресторана по названию
curl -X GET "$BASE_URL/restaurants/?search=кафе"

# Вторая страница
curl -X GET "$BASE_URL/restaurants/?page=2"
```

---

## Детали ресторана

`GET /api/v1/restaurants/{id}/`

**Auth:** 🔓 anon  
**Throttle:** 60/min  
**Tags:** restaurants

### Описание

Возвращает данные одного ресторана по числовому идентификатору. Используется на странице ресторана для отображения названия, адреса и категорий.

### Параметры пути

| Параметр | Тип | Описание |
|---|---|---|
| `id` | integer | Числовой идентификатор ресторана |

### Ответы

**200 OK**

```json
{
  "id": 59,
  "name": "Mr.Bull",
  "address": "Цветной бульвар, 9",
  "categories": []
}
```

Поле `categories` — массив объектов категорий (может быть пустым, если у ресторана нет привязанных категорий). Каждый элемент:

```json
{
  "id": 3,
  "name": "Европейская",
  "icon": "🍽",
  "color": "#F5F0E8",
  "mode": "cuisines"
}
```

**404 Not Found** — ресторан с таким `id` не существует.

```json
{
  "detail": "No Restaurant matches the given query."
}
```

**429 Too Many Requests** — см. [conventions.md#throttle](../conventions.md#throttle).

### Пример

```bash
export BASE_URL=https://foody.press/api/v1

curl -X GET "$BASE_URL/restaurants/59/"
```

---

## Список блюд

`GET /api/v1/dishes/`

**Auth:** 🔓 anon  
**Throttle:** 60/min  
**Tags:** restaurants

### Описание

Возвращает постраничный список блюд. Основной сценарий использования — подгрузка меню конкретного ресторана через параметр `?restaurant_id=N`.

Если параметр `restaurant_id` не передан, возвращаются все блюда из базы (все рестораны). Поддерживает полнотекстовый поиск по `name` через `?search=`.

Пагинация — стандартная `PageNumberPagination` с `page_size=20`; параметр `?page_size=` **не поддерживается**. Только `?page=N`. Подробнее — [conventions.md#pagination](../conventions.md#pagination).

### Query-параметры

| Параметр | Тип | Required | Default | Описание |
|---|---|---|---|---|
| `restaurant_id` | integer | Нет | — | Фильтр по ресторану. Без параметра — все блюда |
| `page` | integer | Нет | 1 | Номер страницы |
| `search` | string | Нет | — | Полнотекстовый поиск по `name` |

### Ответы

**200 OK**

```json
{
  "count": 3,
  "next": null,
  "previous": null,
  "results": [
    {
      "id": 24,
      "name": "API-TEST-DISH-2-2026",
      "restaurant": 12,
      "categories": []
    },
    {
      "id": 23,
      "name": "API-TEST-DISH-2026-05-18",
      "restaurant": 12,
      "categories": []
    },
    {
      "id": 25,
      "name": "API-TEST-DISH-3",
      "restaurant": 12,
      "categories": []
    }
  ]
}
```

Поле `restaurant` — числовой `id` родительского ресторана. Поле `categories` — массив категорий блюда (может быть пустым). Структура элемента аналогична категориям ресторана.

**429 Too Many Requests** — см. [conventions.md#throttle](../conventions.md#throttle).

### Пример

```bash
export BASE_URL=https://foody.press/api/v1

# Блюда конкретного ресторана (id=12)
curl -X GET "$BASE_URL/dishes/?restaurant_id=12"

# Поиск блюда по названию
curl -X GET "$BASE_URL/dishes/?search=стейк"
```

### Замечания

- Поле `restaurant` в объекте блюда — числовой id, не объект. Название ресторана отдельным запросом не нужно: при показе блюд в контексте конкретного ресторана оно уже известно из параметра `restaurant_id`.
- Уникальность блюда обеспечивается парой `(restaurant, name)`. Одно и то же название может встречаться у разных ресторанов.
