# Users

Пользователи Foody: регистрация, просмотр и редактирование профиля, подписки на других пользователей, удаление аккаунта. Профили доступны анонимно, но полный набор полей (email, дата рождения и т.п.) возвращается только самому пользователю.

## Эндпоинты

| Метод | Путь | Auth | Throttle | Описание |
|---|---|---|---|---|
| POST | `/api/v1/users/register/` | 🔓 anon | 60/min | Регистрация нового пользователя |
| GET | `/api/v1/users/check-email/` | 🔓 anon | 60/min | Проверить, занят ли email |
| GET | `/api/v1/users/check-username/` | 🔓 anon | 60/min | Проверить, занят ли username |
| GET | `/api/v1/users/me/` | 🔒 user | 300/min | Получить профиль текущего пользователя |
| PATCH | `/api/v1/users/me/` | 🔒 user | 300/min | Обновить профиль текущего пользователя |
| DELETE | `/api/v1/users/me/` | 🔒 user | 300/min | Удалить аккаунт |
| GET | `/api/v1/users/{user_id}/` | 🔓 anon | 60/min | Получить публичный профиль пользователя |
| POST | `/api/v1/users/{user_id}/subscribe/` | 🔒 user | 300/min | Подписаться на пользователя |
| DELETE | `/api/v1/users/{user_id}/subscribe/` | 🔒 user | 300/min | Отписаться от пользователя |

---

## Регистрация

`POST /api/v1/users/register/` — описание, тело запроса, формат ответа и примеры
вынесены в [auth.md#register](../auth.md#register).

## Проверка email и username

`GET /api/v1/users/check-email/` и `GET /api/v1/users/check-username/` — описание
и примеры в [auth.md#availability-checks](../auth.md#availability-checks).

---

## Получить свой профиль

`GET /api/v1/users/me/`

**Auth:** 🔒 user  
**Throttle:** 300/min (см. [conventions.md#throttle](../conventions.md#throttle))  
**Tags:** users

### Описание

Возвращает полный профиль текущего авторизованного пользователя. Включает все поля, в том числе приватные (`email`, `birth_date`, `date_joined`), которые скрываются при просмотре чужих профилей.

Требует валидного JWT в заголовке `Authorization`. Порядок получения токена — см. [auth.md#jwt-obtain](../auth.md#jwt-obtain).

### Ответы

**200 OK** — профиль текущего пользователя

```json
{
  "id": 73,
  "username": "test_user1",
  "email": "test_user1@test.local",
  "full_name": "Test User 1",
  "bio_text": "",
  "avatar": null,
  "birth_date": null,
  "city": "Москва",
  "date_joined": "2026-05-19T19:56:20.108484Z",
  "is_staff": false,
  "posts_count": 0,
  "followers_count": 0,
  "following_count": 0,
  "is_following": false
}
```

| Поле | Тип | Описание |
|---|---|---|
| `id` | integer | Идентификатор пользователя |
| `username` | string | Никнейм |
| `email` | string | Email (только для self-запроса) |
| `full_name` | string | Полное имя |
| `bio_text` | string | Биография, до 280 символов |
| `avatar` | string\|null | Относительный URL аватара `/media/...` или `null` (см. [conventions.md#media-urls](../conventions.md#media-urls)) |
| `birth_date` | string\|null | Дата рождения ISO 8601, только для self-запроса |
| `city` | string | Город |
| `date_joined` | string | Дата регистрации ISO 8601, только для self-запроса |
| `is_staff` | boolean | Флаг модератора, только для self-запроса (или если смотрит staff) |
| `posts_count` | integer | Количество опубликованных (approved) постов |
| `followers_count` | integer | Количество подписчиков |
| `following_count` | integer | Количество подписок |
| `is_following` | boolean | Всегда `false` для self-запроса |

**401 Unauthorized** — токен отсутствует или недействителен, см. [errors.md#401](../errors.md#401).

### Пример

```bash
export BASE_URL=https://foody.press/api/v1
export TOKEN=<access_token>  # см. auth.md#jwt-obtain

curl "$BASE_URL/users/me/" \
  -H "Authorization: Bearer $TOKEN"
```

---

## Обновить свой профиль

`PATCH /api/v1/users/me/`

**Auth:** 🔒 user  
**Throttle:** 300/min (см. [conventions.md#throttle](../conventions.md#throttle))  
**Tags:** users

### Описание

Частичное обновление профиля текущего пользователя. Передавать нужно только изменяемые поля. Email и другие read-only поля (`id`, `date_joined`, `is_staff`, `followers_count`, `following_count`) принимаются, но игнорируются.

### Тело запроса

```json
{
  "bio_text": "Люблю японскую кухню",
  "city": "Санкт-Петербург"
}
```

| Поле | Тип | Required | Описание |
|---|---|---|---|
| `username` | string | нет | Новый никнейм |
| `full_name` | string | нет | Полное имя, до 120 символов, не может быть пустым при передаче |
| `bio_text` | string | нет | Биография до 280 символов. HTML-теги очищаются автоматически |
| `city` | string | нет | Город, до 100 символов, не может быть пустым при передаче |
| `birth_date` | string | нет | Дата рождения в формате `YYYY-MM-DD` |
| `avatar` | file | нет | Файл аватара (multipart/form-data; для удаления передать пустую строку не поддерживается) |

### Ответы

**200 OK** — возвращает полный обновлённый профиль (те же поля, что и `GET /users/me/`)

```json
{
  "id": 73,
  "username": "test_user1",
  "email": "test_user1@test.local",
  "full_name": "Test User 1",
  "bio_text": "Test bio for documentation",
  "avatar": null,
  "birth_date": null,
  "city": "Москва",
  "date_joined": "2026-05-19T19:56:20.108484Z",
  "is_staff": false,
  "posts_count": 0,
  "followers_count": 0,
  "following_count": 0,
  "is_following": false
}
```

**400 Bad Request** — ошибки валидации (например, пустой `full_name`), см. [errors.md#400](../errors.md#400).

**401 Unauthorized** — см. [errors.md#401](../errors.md#401).

### Пример (JSON-поля)

```bash
export BASE_URL=https://foody.press/api/v1
export TOKEN=<access_token>

curl -X PATCH "$BASE_URL/users/me/" \
  -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' \
  -d '{"bio_text": "Люблю японскую кухню", "city": "Санкт-Петербург"}'
```

### Пример (загрузка аватара)

```bash
curl -X PATCH "$BASE_URL/users/me/" \
  -H "Authorization: Bearer $TOKEN" \
  -F "avatar=@/path/to/photo.jpg" \
  -F "bio_text=Люблю японскую кухню"
```

### Замечания

- `bio_text` очищается от HTML-тегов на сервере (bleach).
- `email` — read-only, изменить email через этот эндпоинт нельзя.
- Формат аватара: относительный URL `/media/...`, склейку с базовым URL выполняет фронт (см. [conventions.md#media-urls](../conventions.md#media-urls)).

---

## Удалить аккаунт

`DELETE /api/v1/users/me/` — описание, ответ 204 и инструкция по очистке JWT на
клиенте — в [auth.md#account-delete](../auth.md#account-delete).

---

## Профиль пользователя

`GET /api/v1/users/{user_id}/`

**Auth:** 🔓 anon (🔒 user для поля `is_following`)  
**Throttle:** 60/min anon / 300/min user (см. [conventions.md#throttle](../conventions.md#throttle))  
**Tags:** users

### Описание

Возвращает публичный профиль пользователя по числовому `user_id`. Поиск по username не поддерживается — только по числовому идентификатору. Эндпоинта `/users/by-username/...` не существует (см. [errors.md#404](../errors.md#404)).

Набор полей зависит от роли запрашивающего (см. [conventions.md#pii](../conventions.md#pii)):
- **Anon или другой пользователь**: возвращаются только публичные поля; `email`, `birth_date`, `date_joined` скрыты.
- **Сам пользователь** (`/users/me/`): все поля доступны.
- **Staff-пользователь**: дополнительно видит `is_staff` цели.

### Параметры пути

| Параметр | Тип | Описание |
|---|---|---|
| `user_id` | integer | Числовой идентификатор пользователя |

### Ответы

**200 OK** — публичный профиль (вид от другого аутентифицированного пользователя)

```json
{
  "id": 74,
  "username": "test_user2",
  "full_name": "Test User 2",
  "bio_text": "Тестовый аккаунт для документации",
  "avatar": null,
  "city": "Москва",
  "posts_count": 1,
  "followers_count": 0,
  "following_count": 0,
  "is_following": false
}
```

Поля `email`, `birth_date`, `date_joined`, `is_staff` отсутствуют в ответе — они скрыты PII-фильтром сериализатора.

**404 Not Found** — пользователь с таким `user_id` не существует:

```json
{
  "detail": "No User matches the given query."
}
```

### Пример

```bash
export BASE_URL=https://foody.press/api/v1

# Анонимный запрос
curl "$BASE_URL/users/74/"

# Авторизованный запрос (поле is_following будет отражать реальное состояние)
curl "$BASE_URL/users/74/" \
  -H "Authorization: Bearer $TOKEN"
```

### Замечания

- Поиска по username нет — только по числовому `id`. Если идентификатор неизвестен, его можно получить из `id` в ответе на `GET /users/me/` или из объектов постов.
- Поле `is_following` возвращает `false` для анонимных запросов и для self-запросов.

---

## Подписаться на пользователя

`POST /api/v1/users/{user_id}/subscribe/`

**Auth:** 🔒 user  
**Throttle:** 300/min (см. [conventions.md#throttle](../conventions.md#throttle))  
**Tags:** users

### Описание

Подписывает текущего пользователя на пользователя с `user_id`. Операция идемпотентна: повторный вызов не создаёт дублирующей подписки и возвращает тот же формат ответа с `"created": false`.

Семантика — см. [conventions.md#toggle-semantics](../conventions.md#toggle-semantics).

> **Важно:** эндпоинты `/follow/` и `/unfollow/` не существуют в API и вернут 404. Используйте только `POST /subscribe/` и `DELETE /subscribe/`.

### Параметры пути

| Параметр | Тип | Описание |
|---|---|---|
| `user_id` | integer | Числовой идентификатор пользователя, на которого подписываемся |

Тело запроса не требуется.

### Ответы

**200 OK** — подписка создана или уже существовала

```json
{
  "status": "followed",
  "created": true
}
```

```json
{
  "status": "followed",
  "created": false
}
```

| Поле | Тип | Описание |
|---|---|---|
| `status` | string | Всегда `"followed"` |
| `created` | boolean | `true` — подписка только что создана; `false` — уже существовала |

**400 Bad Request** — попытка подписаться на самого себя:

```json
{
  "error": "Нельзя подписаться на себя"
}
```

**401 Unauthorized** — см. [errors.md#401](../errors.md#401).

**404 Not Found** — пользователь с `user_id` не существует, см. [errors.md#404](../errors.md#404).

### Пример

```bash
export BASE_URL=https://foody.press/api/v1
export TOKEN=<access_token>

curl -X POST "$BASE_URL/users/74/subscribe/" \
  -H "Authorization: Bearer $TOKEN"
```

---

## Отписаться от пользователя

`DELETE /api/v1/users/{user_id}/subscribe/`

**Auth:** 🔒 user  
**Throttle:** 300/min (см. [conventions.md#throttle](../conventions.md#throttle))  
**Tags:** users

### Описание

Удаляет подписку текущего пользователя на пользователя с `user_id`. Операция идемпотентна: если подписки нет — всё равно возвращает 204.

Cм. также [conventions.md#toggle-semantics](../conventions.md#toggle-semantics).

### Параметры пути

| Параметр | Тип | Описание |
|---|---|---|
| `user_id` | integer | Числовой идентификатор пользователя, от которого отписываемся |

### Ответы

**204 No Content** — подписка удалена (или не существовала), тело ответа отсутствует.

**401 Unauthorized** — см. [errors.md#401](../errors.md#401).

**404 Not Found** — пользователь с `user_id` не существует, см. [errors.md#404](../errors.md#404).

### Пример

```bash
export BASE_URL=https://foody.press/api/v1
export TOKEN=<access_token>

curl -X DELETE "$BASE_URL/users/74/subscribe/" \
  -H "Authorization: Bearer $TOKEN"
# HTTP 204 — тела нет
```
