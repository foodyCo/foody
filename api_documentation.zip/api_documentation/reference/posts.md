# Posts

Посты — основная единица контента в Foody. Каждый пост описывает опыт пользователя с блюдом в ресторане: фотографии, описание, цена, рейтинг и теги.

После создания пост получает статус `pending` и не появляется в публичной ленте до одобрения модератором.
Подробнее о жизненном цикле поста: [conventions.md#post-lifecycle](../conventions.md#post-lifecycle).

---

## Эндпоинты

| Метод | Путь | Auth | Throttle | Описание |
|---|---|---|---|---|
| GET | `/api/v1/posts/` | 🔓 anon | 60/min | Публичная лента (только approved) |
| POST | `/api/v1/posts/` | 🔒 user | 300/min | Создать пост (multipart/form-data) |
| GET | `/api/v1/posts/{id}/` | 🔓 anon | 60/min | Получить пост по ID |
| PATCH | `/api/v1/posts/{id}/` | 🔒 owner | 300/min | Обновить пост (сбрасывает статус на pending) |
| PUT | `/api/v1/posts/{id}/` | 🔒 owner | 300/min | Полное обновление поста (аналогично PATCH) |
| DELETE | `/api/v1/posts/{id}/` | 🔒 owner / 👮 staff | 300/min | Удалить пост |
| GET | `/api/v1/posts/my/` | 🔒 user | 300/min | Свои посты (все статусы) |
| GET | `/api/v1/posts/saved/` | 🔒 user | 300/min | Сохранённые посты |
| GET | `/api/v1/posts/user_posts/` | 🔓 anon | 60/min | Посты конкретного пользователя |
| GET | `/api/v1/posts/following/` | 🔒 user | 300/min | Посты подписок |
| GET | `/api/v1/posts/liked/` | 🔒 user | 300/min | Понравившиеся посты |
| POST | `/api/v1/posts/{id}/like/` | 🔒 user | 300/min | Toggle лайка на пост |
| POST | `/api/v1/posts/{id}/save_post/` | 🔒 user | 300/min | Toggle сохранения поста |
| GET | `/api/v1/posts/{id}/comments/` | 🔓 anon | 60/min | Список комментариев к посту |
| POST | `/api/v1/posts/{id}/comments/` | 🔒 user | 300/min | Добавить комментарий |
| DELETE | `/api/v1/posts/{id}/comments/{comment_pk}/` | 🔒 author / 👮 staff | 300/min | Удалить комментарий |
| POST | `/api/v1/comments/{comment_id}/like/` | 🔒 user | 300/min | Toggle лайка на комментарий |
| DELETE | `/api/v1/comments/{comment_id}/like/` | 🔒 user | 300/min | Снять лайк с комментария (без toggle) |
| GET | `/api/v1/comments/likes/` | 🔒 user | 300/min | Batch-запрос статуса лайков комментариев |

---

## Список постов (лента)

`GET /api/v1/posts/`

**Auth:** 🔓 anon  
**Throttle:** 60/min (anon), 300/min (user) — см. [conventions.md#throttle](../conventions.md#throttle)  
**Tags:** posts

### Описание

Возвращает постраничный список одобренных (`approved`) постов в обратном хронологическом порядке. Доступен без авторизации.

Авторизованный пользователь получает дополнительные поля `is_liked` и `is_saved`, отражающие его персональное состояние. Без токена оба поля равны `false`.

Поддерживаются фильтрация, поиск и сортировка — см. [conventions.md#filters](../conventions.md#filters).

### Query-параметры

| Параметр | Тип | Required | Default | Описание |
|---|---|---|---|---|
| `page` | integer | нет | 1 | Номер страницы |
| `page_size` | integer | нет | 20 | Размер страницы (max 100) |
| `search` | string | нет | — | Полнотекстовый поиск по блюду, ресторану, тегам, категориям |
| `ordering` | string | нет | `-created_at,-id` | Поля: `created_at`, `statistics__rating`, `statistics__likes_count`, `price`. Префикс `-` для убывания |
| `tag_id` | integer (или через запятую) | нет | — | Фильтр по ID тега (OR-логика при нескольких значениях) |
| `tag_name` | string | нет | — | Фильтр по имени тега (без учёта регистра) |
| `author` / `user_id` / `user` | integer | нет | — | Фильтр по ID автора |
| `restaurant_id` | integer | нет | — | Фильтр по ID ресторана |
| `category_id` | integer | нет | — | Фильтр по ID категории (по блюду или ресторану) |
| `city` | string | нет | — | Фильтр по адресу ресторана (icontains) |
| `price_min` | number (≥0) | нет | — | Минимальная цена |
| `price_max` | number (≥0) | нет | — | Максимальная цена |

### Ответы

**200 OK**

```json
{
  "count": 5,
  "next": "https://foody.press/api/v1/posts/?page=2&page_size=2",
  "previous": null,
  "results": [
    {
      "id": 190,
      "user": {
        "id": 74,
        "username": "user",
        "full_name": "Test User",
        "avatar": null,
        "is_following": false
      },
      "restaurant": 67,
      "restaurant_name": "Солнышко",
      "restaurant_address": "Крупская 35",
      "dish": 171,
      "dish_name": "Каша овсяная",
      "description": "Вкусная кашка как в детстве",
      "price": "200.00",
      "created_at": "2026-05-20T12:19:39.430751Z",
      "images": [
        {
          "id": 88,
          "image": "/media/post_images/1727.jpg",
          "uploaded_at": "2026-05-20T12:19:39.454899Z"
        }
      ],
      "statistics": {
        "likes_count": 1,
        "saves_count": 1,
        "comments_count": 2,
        "rating": 4.0
      },
      "tags": [
        {"id": 9, "name": "русская"},
        {"id": 74, "name": "каша"}
      ],
      "categories": [],
      "is_liked": false,
      "is_saved": false,
      "status": "approved",
      "rejection_reason": null
    }
  ]
}
```

Пагинация: [conventions.md#pagination](../conventions.md#pagination).  
Поле `images[].image` — относительный путь: [conventions.md#media-urls](../conventions.md#media-urls).

**400 Bad Request** — если `price_min` или `price_max` содержат отрицательное значение.

**429 Too Many Requests** — [conventions.md#throttle](../conventions.md#throttle).

### Пример

```bash
export BASE_URL=https://foody.press/api/v1

curl -s "$BASE_URL/posts/?ordering=-statistics__rating&page_size=5"
```

---

## Создать пост

`POST /api/v1/posts/`

**Auth:** 🔒 user  
**Throttle:** 300/min  
**Content-Type:** `multipart/form-data`  
**Tags:** posts

### Описание

Создаёт новый пост. Принимает только `multipart/form-data` — для передачи файлов фотографий. Пост создаётся со статусом `pending` и не будет виден в публичной ленте до одобрения модератором.

Ресторан и блюдо указываются двумя способами:
- Передать `restaurant_id` (ID существующего ресторана) + `dish_name`.
- Передать `restaurant_name` + `restaurant_address` + `dish_name` — ресторан и блюдо будут созданы или найдены по имени (идемпотентно, регистронезависимо).

**Важно:** drf-spectacular не отображает точный контракт этого эндпоинта — источник истины код `PostCreateSerializer` в `backend/posts/serializers.py`.

### Тело запроса (multipart/form-data)

| Поле | Тип | Required | Описание |
|---|---|---|---|
| `dish_name` | string (max 50) | **да** | Название блюда |
| `rating` | float (0–10) | **да** | Оценка блюда (создаёт `PostReview`) |
| `restaurant_id` | integer | нет* | ID существующего ресторана |
| `restaurant_name` | string (max 255) | нет* | Название ресторана (если нет `restaurant_id`) |
| `restaurant_address` | string (max 100) | нет | Адрес ресторана (используется при создании нового) |
| `description` | string (max 2000) | нет | Описание блюда (HTML стрипается, plain text) |
| `price` | number (≥0) | нет | Цена блюда |
| `uploaded_images` | file (повторяется) | нет | Фотографии (макс. 10 МБ каждая; EXIF стрипается) |
| `tags_list` | string (повторяется, max 50) | нет | Теги (нормализуются к нижнему регистру) |

\* Обязателен один из вариантов: `restaurant_id` **или** `restaurant_name`.

### Ответы

**201 Created** — полный граф поста (формат `PostListSerializer`, как в ленте)

```json
{
  "id": 191,
  "user": {
    "id": 73,
    "username": "test_user1",
    "full_name": "Test User 1",
    "avatar": null,
    "is_following": false
  },
  "restaurant": 68,
  "restaurant_name": "Тестовый ресторан",
  "restaurant_address": "Тестовая улица 1",
  "dish": 172,
  "dish_name": "Тестовое блюдо",
  "description": "Тестовое описание",
  "price": "350.00",
  "created_at": "2026-05-20T20:14:26.038726Z",
  "images": [],
  "statistics": {
    "likes_count": 0,
    "saves_count": 0,
    "comments_count": 0,
    "rating": 0.0
  },
  "tags": [],
  "categories": [],
  "is_liked": false,
  "is_saved": false,
  "status": "pending",
  "rejection_reason": null
}
```

**400 Bad Request** — поля не прошли валидацию

```json
{"dish_name": ["Обязательное поле."]}
```

```json
{"restaurant": ["Необходимо передать restaurant_id или restaurant_name."]}
```

```json
{"restaurant_id": ["Ресторан с таким ID не существует."]}
```

**401 Unauthorized** — токен не передан или недействителен — [errors.md#401](../errors.md#401).

**429 Too Many Requests** — [conventions.md#throttle](../conventions.md#throttle).

### Пример

```bash
export BASE_URL=https://foody.press/api/v1
export TOKEN=<ваш access-токен>

curl -s -X POST "$BASE_URL/posts/" \
  -H "Authorization: Bearer $TOKEN" \
  -F "dish_name=Том-ям" \
  -F "restaurant_name=Тайская кухня" \
  -F "restaurant_address=Москва, ул. Арбат 12" \
  -F "rating=8.5" \
  -F "description=Насыщенный суп с лемонграссом" \
  -F "price=550" \
  -F "tags_list=суп" \
  -F "tags_list=тайская" \
  -F "uploaded_images=@/path/to/photo.jpg"
```

### Замечания

- Ответ возвращает `PostListSerializer` (полный граф), а не `PostCreateSerializer` — это расхождение с drf-spectacular.
- `status` в ответе всегда `"pending"` — пост нужно одобрить через `/api/v1/moderation/{id}/approve/`.
- `rating` создаёт запись `PostReview` и включается в статистику после периодической задачи Celery.

---

## Получить пост

`GET /api/v1/posts/{id}/`

**Auth:** 🔓 anon  
**Throttle:** 60/min (anon), 300/min (user)  
**Tags:** posts

### Описание

Возвращает один пост по ID. Анонимные и авторизованные пользователи видят только `approved` посты. Исключение: владелец поста может получить свой `pending` или `rejected` пост по прямому ID.

### Параметры пути

| Параметр | Тип | Описание |
|---|---|---|
| `id` | integer | ID поста |

### Ответы

**200 OK** — структура идентична одному элементу из `results[]` в `GET /posts/` (см. выше).

**401 Unauthorized** — токен недействителен — [errors.md#401](../errors.md#401).

**404 Not Found** — пост не существует или недоступен текущему пользователю.

```json
{"detail": "No Post matches the given query."}
```

### Пример

```bash
export BASE_URL=https://foody.press/api/v1
export TOKEN=<ваш access-токен>
export POST_ID=190

curl -s "$BASE_URL/posts/$POST_ID/" \
  -H "Authorization: Bearer $TOKEN"
```

---

## Обновить пост

`PATCH /api/v1/posts/{id}/`

**Auth:** 🔒 owner  
**Throttle:** 300/min  
**Content-Type:** `multipart/form-data`  
**Tags:** posts

### Описание

Обновляет поля существующего поста. Только автор поста может выполнить это действие. После любого обновления `status` сбрасывается в `"pending"`, а поля `moderated_by` и `moderated_at` обнуляются — пост уходит на повторную модерацию.

`PUT /api/v1/posts/{id}/` работает идентично `PATCH` (DRF стандартное поведение `update`).

### Параметры пути

| Параметр | Тип | Описание |
|---|---|---|
| `id` | integer | ID поста |

### Тело запроса (multipart/form-data)

| Поле | Тип | Required | Описание |
|---|---|---|---|
| `description` | string (max 2000) | нет | Новое описание (HTML стрипается) |
| `price` | number (≥0) | нет | Новая цена |
| `tags_list` | string (повторяется, max 50) | нет | Полная замена тегов |
| `uploaded_images` | file (повторяется) | нет | Добавить фотографии (append, не замена; макс. 10 МБ каждая) |

### Ответы

**200 OK** — полный граф поста (`PostListSerializer`), `status` всегда `"pending"` после обновления.

**400 Bad Request** — ошибки валидации.

**403 Forbidden** — попытка изменить чужой пост.

**404 Not Found** — пост не найден или не принадлежит текущему пользователю.

**401 Unauthorized** — токен не передан или недействителен — [errors.md#401](../errors.md#401).

### Пример

```bash
export BASE_URL=https://foody.press/api/v1
export TOKEN=<ваш access-токен>
export POST_ID=191

curl -s -X PATCH "$BASE_URL/posts/$POST_ID/" \
  -H "Authorization: Bearer $TOKEN" \
  -F "description=Уточнённое описание" \
  -F "price=600"
```

### Замечания

- `uploaded_images` работает в режиме **append**: новые фото добавляются к существующим, старые не удаляются.
- Если передать `tags_list`, теги **полностью заменяются** (не добавляются).
- После PATCH/PUT пост исчезнет из публичной ленты до повторного одобрения (см. [conventions.md#post-lifecycle](../conventions.md#post-lifecycle)).

---

## Удалить пост

`DELETE /api/v1/posts/{id}/`

**Auth:** 🔒 owner / 👮 staff  
**Throttle:** 300/min  
**Tags:** posts

### Описание

Удаляет пост. Автор может удалить свой пост любого статуса. Модератор (`is_staff=True`) может удалить любой пост.

### Параметры пути

| Параметр | Тип | Описание |
|---|---|---|
| `id` | integer | ID поста |

### Ответы

**204 No Content** — пост успешно удалён.

**403 Forbidden** — попытка удалить чужой пост (не автор и не staff).

```json
{"error": "Нельзя удалить чужой пост"}
```

**401 Unauthorized** — токен не передан — [errors.md#401](../errors.md#401).

### Пример

```bash
export BASE_URL=https://foody.press/api/v1
export TOKEN=<ваш access-токен>
export POST_ID=191

curl -s -X DELETE "$BASE_URL/posts/$POST_ID/" \
  -H "Authorization: Bearer $TOKEN" \
  -w "\nHTTP %{http_code}"
```

---

## Мои посты

`GET /api/v1/posts/my/`

**Auth:** 🔒 user  
**Throttle:** 300/min  
**Tags:** posts

### Описание

Возвращает постраничный список постов текущего авторизованного пользователя, включая посты всех статусов: `pending`, `rejected`, `approved`. Применяются те же фильтры и параметры сортировки, что и в основной ленте.

### Query-параметры

Те же, что и у `GET /api/v1/posts/` (пагинация, фильтры, поиск, ordering).

### Ответы

**200 OK** — формат идентичен `GET /posts/`, но в `results[]` могут присутствовать посты со статусом `"pending"` или `"rejected"`.

```json
{
  "count": 0,
  "next": null,
  "previous": null,
  "results": []
}
```

**401 Unauthorized** — [errors.md#401](../errors.md#401).

### Пример

```bash
export BASE_URL=https://foody.press/api/v1
export TOKEN=<ваш access-токен>

curl -s "$BASE_URL/posts/my/" \
  -H "Authorization: Bearer $TOKEN"
```

---

## Сохранённые посты

`GET /api/v1/posts/saved/`

**Auth:** 🔒 user  
**Throttle:** 300/min  
**Tags:** posts

### Описание

Возвращает постраничный список постов, которые текущий пользователь добавил в закладки через `POST /posts/{id}/save_post/`. Только `approved` посты могут находиться в сохранённых.

### Query-параметры

Те же, что у `GET /api/v1/posts/`.

### Ответы

**200 OK** — формат идентичен `GET /posts/`.

**401 Unauthorized** — [errors.md#401](../errors.md#401).

### Пример

```bash
export BASE_URL=https://foody.press/api/v1
export TOKEN=<ваш access-токен>

curl -s "$BASE_URL/posts/saved/" \
  -H "Authorization: Bearer $TOKEN"
```

---

## Посты пользователя

`GET /api/v1/posts/user_posts/`

**Auth:** 🔓 anon  
**Throttle:** 60/min (anon), 300/min (user)  
**Tags:** posts

### Описание

Возвращает постраничный список постов конкретного пользователя по его ID. Публичный эндпоинт: анонимный пользователь видит только `approved` посты. Авторизованный владелец, запрашивающий собственные посты, видит также `pending` и `rejected`.

### Query-параметры

| Параметр | Тип | Required | Описание |
|---|---|---|---|
| `user_id` | integer | **да** | ID пользователя |
| `page` | integer | нет | Номер страницы |
| `page_size` | integer | нет | Размер страницы (max 100) |
| + прочие фильтры | — | нет | Те же, что у `GET /posts/` |

### Ответы

**200 OK** — формат идентичен `GET /posts/`.

**400 Bad Request** — `user_id` не передан.

```json
{"error": "user_id is required"}
```

### Пример

```bash
export BASE_URL=https://foody.press/api/v1

curl -s "$BASE_URL/posts/user_posts/?user_id=74"
```

---

## Посты подписок

`GET /api/v1/posts/following/`

**Auth:** 🔒 user  
**Throttle:** 300/min  
**Tags:** posts

### Описание

Возвращает постраничный список одобренных постов пользователей, на которых подписан текущий пользователь.

### Query-параметры

Те же, что у `GET /api/v1/posts/`.

### Ответы

**200 OK** — формат идентичен `GET /posts/`. Пустой `results[]` если нет подписок или у подписок нет approved-постов.

**401 Unauthorized** — [errors.md#401](../errors.md#401).

### Пример

```bash
export BASE_URL=https://foody.press/api/v1
export TOKEN=<ваш access-токен>

curl -s "$BASE_URL/posts/following/" \
  -H "Authorization: Bearer $TOKEN"
```

---

## Понравившиеся посты

`GET /api/v1/posts/liked/`

**Auth:** 🔒 user  
**Throttle:** 300/min  
**Tags:** posts

### Описание

Возвращает постраничный список одобренных постов, которые текущий пользователь лайкнул.

### Query-параметры

Те же, что у `GET /api/v1/posts/`.

### Ответы

**200 OK** — формат идентичен `GET /posts/`.

**401 Unauthorized** — [errors.md#401](../errors.md#401).

### Пример

```bash
export BASE_URL=https://foody.press/api/v1
export TOKEN=<ваш access-токен>

curl -s "$BASE_URL/posts/liked/" \
  -H "Authorization: Bearer $TOKEN"
```

---

## Лайк поста

`POST /api/v1/posts/{id}/like/`

**Auth:** 🔒 user  
**Throttle:** 300/min  
**Tags:** posts

### Описание

Toggle лайка на пост. Первый вызов ставит лайк (`"liked": true`), повторный — убирает (`"liked": false`). Ответ содержит **новое** состояние после операции. Тело запроса не требуется.

Параллельные вызовы от одного пользователя сериализуются через `select_for_update` — финальное состояние всегда соответствует чётности кликов.

Toggle-семантика: [conventions.md#toggle-semantics](../conventions.md#toggle-semantics).

### Параметры пути

| Параметр | Тип | Описание |
|---|---|---|
| `id` | integer | ID поста |

### Ответы

**200 OK** — новое состояние лайка

```json
{"liked": true}
```

```json
{"liked": false}
```

**401 Unauthorized** — [errors.md#401](../errors.md#401).

**403 Forbidden** — автор пытается лайкнуть собственный `pending` или `rejected` пост (см. [conventions.md#post-lifecycle](../conventions.md#post-lifecycle)).

```json
{"detail": "Нельзя лайкать собственный пост до одобрения модератором."}
```

**404 Not Found** — пост не существует или недоступен (чужой `pending`/`rejected`).

### Пример

```bash
export BASE_URL=https://foody.press/api/v1
export TOKEN=<ваш access-токен>
export POST_ID=190

# Поставить лайк
curl -s -X POST "$BASE_URL/posts/$POST_ID/like/" \
  -H "Authorization: Bearer $TOKEN"

# Повторный вызов убирает лайк
curl -s -X POST "$BASE_URL/posts/$POST_ID/like/" \
  -H "Authorization: Bearer $TOKEN"
```

---

## Сохранение поста

`POST /api/v1/posts/{id}/save_post/`

**Auth:** 🔒 user  
**Throttle:** 300/min  
**Tags:** posts

### Описание

Toggle закладки на пост. Работает аналогично `like/`: первый вызов добавляет в закладки, повторный — убирает. Ответ содержит новое состояние.

В отличие от лайка, сохранить можно любой видимый пользователю пост — в том числе собственный `pending` (это персональный bookmark, не публичный сигнал).

Toggle-семантика: [conventions.md#toggle-semantics](../conventions.md#toggle-semantics).

### Параметры пути

| Параметр | Тип | Описание |
|---|---|---|
| `id` | integer | ID поста |

### Ответы

**200 OK** — новое состояние закладки

```json
{"saved": true}
```

```json
{"saved": false}
```

**401 Unauthorized** — [errors.md#401](../errors.md#401).

**404 Not Found** — пост не существует или недоступен.

### Пример

```bash
export BASE_URL=https://foody.press/api/v1
export TOKEN=<ваш access-токен>
export POST_ID=190

curl -s -X POST "$BASE_URL/posts/$POST_ID/save_post/" \
  -H "Authorization: Bearer $TOKEN"
```

---

## Комментарии к посту

`GET /api/v1/posts/{id}/comments/`  
`POST /api/v1/posts/{id}/comments/`

**Auth:** GET — 🔓 anon; POST — 🔒 user  
**Throttle:** 60/min (anon GET), 300/min (user)  
**Tags:** posts

### Описание

**GET** — возвращает постраничный список комментариев к посту. Доступен без авторизации.

**POST** — создаёт новый комментарий от имени текущего пользователя. HTML-теги в тексте стрипаются (plain text, защита от XSS).

### Параметры пути

| Параметр | Тип | Описание |
|---|---|---|
| `id` | integer | ID поста |

### Тело запроса (POST, application/json)

```json
{"text": "Вкусно выглядит!"}
```

| Поле | Тип | Required | Описание |
|---|---|---|---|
| `text` | string (max 2000) | **да** | Текст комментария (HTML стрипается) |

### Ответы

**200 OK (GET)** — постраничный список комментариев

```json
{
  "count": 2,
  "next": null,
  "previous": null,
  "results": [
    {
      "id": 176,
      "user": 1,
      "user_detail": {
        "id": 1,
        "username": "admin",
        "full_name": "admin",
        "avatar": null,
        "is_following": false
      },
      "text": "Нормальная тема",
      "created_at": "2026-05-20T12:39:55.168752Z",
      "likes_count": 1,
      "is_liked": false
    }
  ]
}
```

**201 Created (POST)** — созданный комментарий

```json
{
  "id": 178,
  "user": 73,
  "user_detail": {
    "id": 73,
    "username": "test_user1",
    "full_name": "Test User 1",
    "avatar": null,
    "is_following": false
  },
  "text": "Вкусно выглядит!",
  "created_at": "2026-05-20T20:13:56.675474Z",
  "likes_count": 0,
  "is_liked": false
}
```

**400 Bad Request** — пустой или невалидный текст.

```json
{"text": ["Текст комментария не может быть пустым."]}
```

**401 Unauthorized (POST)** — [errors.md#401](../errors.md#401).

**404 Not Found** — пост не найден.

### Пример

```bash
export BASE_URL=https://foody.press/api/v1
export TOKEN=<ваш access-токен>
export POST_ID=190

# Получить комментарии
curl -s "$BASE_URL/posts/$POST_ID/comments/"

# Добавить комментарий
curl -s -X POST "$BASE_URL/posts/$POST_ID/comments/" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"text": "Отличное блюдо!"}'
```

---

## Удалить комментарий

`DELETE /api/v1/posts/{id}/comments/{comment_pk}/`

**Auth:** 🔒 author / 👮 staff  
**Throttle:** 300/min  
**Tags:** posts

### Описание

Удаляет комментарий. Автор комментария может удалить свой. Модератор (`is_staff=True`) может удалить любой комментарий. После удаления счётчик `comments_count` в статистике поста уменьшается атомарно через сигнал.

### Параметры пути

| Параметр | Тип | Описание |
|---|---|---|
| `id` | integer | ID поста |
| `comment_pk` | integer | ID комментария |

### Ответы

**204 No Content** — комментарий удалён.

**403 Forbidden** — попытка удалить чужой комментарий (не автор и не staff).

**404 Not Found** — комментарий не найден в рамках данного поста.

**401 Unauthorized** — [errors.md#401](../errors.md#401).

### Пример

```bash
export BASE_URL=https://foody.press/api/v1
export TOKEN=<ваш access-токен>
export POST_ID=190
export COMMENT_ID=178

curl -s -X DELETE "$BASE_URL/posts/$POST_ID/comments/$COMMENT_ID/" \
  -H "Authorization: Bearer $TOKEN" \
  -w "\nHTTP %{http_code}"
```

---

## Лайк комментария

`POST /api/v1/comments/{comment_id}/like/`

**Auth:** 🔒 user  
**Throttle:** 300/min  
**Tags:** posts

### Описание

Toggle лайка на комментарий. Первый вызов ставит лайк, повторный — убирает. Ответ содержит новое состояние и ID комментария.

Параллельные вызовы сериализуются через `select_for_update` (аналогично `POST /posts/{id}/like/`).

Toggle-семантика: [conventions.md#toggle-semantics](../conventions.md#toggle-semantics).

### Параметры пути

| Параметр | Тип | Описание |
|---|---|---|
| `comment_id` | integer | ID комментария |

### Ответы

**200 OK** — новое состояние лайка

```json
{"liked": true, "comment_id": 176}
```

```json
{"liked": false, "comment_id": 176}
```

**401 Unauthorized** — [errors.md#401](../errors.md#401).

**403 Forbidden** — пользователь пытается лайкнуть собственный комментарий на собственном не-одобренном посте (см. [conventions.md#post-lifecycle](../conventions.md#post-lifecycle)).

```json
{"detail": "Нельзя лайкать собственный коммент на не-одобренном посте."}
```

**404 Not Found** — комментарий не найден.

### Пример

```bash
export BASE_URL=https://foody.press/api/v1
export TOKEN=<ваш access-токен>
export COMMENT_ID=176

curl -s -X POST "$BASE_URL/comments/$COMMENT_ID/like/" \
  -H "Authorization: Bearer $TOKEN"
```

---

## Снять лайк с комментария

`DELETE /api/v1/comments/{comment_id}/like/`

**Auth:** 🔒 user  
**Throttle:** 300/min  
**Tags:** posts

### Описание

Явное снятие лайка с комментария без toggle-семантики. Если лайка не было — операция идемпотентна (возвращает 204 без ошибки).

### Параметры пути

| Параметр | Тип | Описание |
|---|---|---|
| `comment_id` | integer | ID комментария |

### Ответы

**204 No Content** — лайк снят (или его и не было).

**401 Unauthorized** — [errors.md#401](../errors.md#401).

### Пример

```bash
export BASE_URL=https://foody.press/api/v1
export TOKEN=<ваш access-токен>
export COMMENT_ID=176

curl -s -X DELETE "$BASE_URL/comments/$COMMENT_ID/like/" \
  -H "Authorization: Bearer $TOKEN" \
  -w "\nHTTP %{http_code}"
```

---

## Batch-статус лайков комментариев

`GET /api/v1/comments/likes/`

**Auth:** 🔒 user  
**Throttle:** 300/min  
**Tags:** posts

### Описание

Возвращает подмножество переданных ID комментариев, которые лайкнуты текущим пользователем. Используется фронтендом для получения статуса лайков для всего видимого списка комментариев за один запрос.

**Важно:** `liked_comment_ids` возвращает строки, не числа (`["176", "177"]`), — это сделано намеренно для единообразного ключирования на фронтенде.

### Query-параметры

| Параметр | Тип | Required | Описание |
|---|---|---|---|
| `ids` | string | **да** | ID комментариев через запятую (например `?ids=176,177,178`) |

### Ответы

**200 OK** — список ID лайкнутых комментариев (строки)

```json
{"liked_comment_ids": ["176"]}
```

Если ни один не лайкнут:

```json
{"liked_comment_ids": []}
```

**400 Bad Request** — некорректные значения в `ids`.

```json
{"detail": "ids должны быть целыми числами через запятую."}
```

**401 Unauthorized** — [errors.md#401](../errors.md#401).

### Пример

```bash
export BASE_URL=https://foody.press/api/v1
export TOKEN=<ваш access-токен>

curl -s "$BASE_URL/comments/likes/?ids=176,177,178" \
  -H "Authorization: Bearer $TOKEN"
```

### Замечания

- Значения в `liked_comment_ids` — строки (`"176"`), не числа (`176`). Обратите внимание при сравнении в JavaScript (`===`).
- Если `ids` не передан или пустой, возвращает `{"liked_comment_ids": []}` без ошибки.
