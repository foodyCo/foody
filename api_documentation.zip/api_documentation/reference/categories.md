# Categories

Справочники категорий блюд/кухонь и тегов. Категории управляются через Django admin и отражаются на фронте без деплоя. Теги создаются автоматически при публикации постов.

## Эндпоинты

| Метод | Путь | Auth | Throttle | Описание |
|---|---|---|---|---|
| GET | `/api/v1/categories/` | 🔓 anon | 60/min | Список всех категорий (paginated) |
| POST | `/api/v1/categories/` | 👮 staff | 300/min | Создать категорию |
| GET | `/api/v1/categories/{id}/` | 🔓 anon | 60/min | Детальная карточка категории |
| PATCH | `/api/v1/categories/{id}/` | 👮 staff | 300/min | Частичное обновление категории |
| PUT | `/api/v1/categories/{id}/` | 👮 staff | 300/min | Полное обновление категории |
| DELETE | `/api/v1/categories/{id}/` | 👮 staff | 300/min | Удалить категорию |
| GET | `/api/v1/categories/popular/` | 🔓 anon | 60/min | Топ категорий по количеству постов |
| GET | `/api/v1/tags/` | 🔓 anon | 60/min | Список всех тегов (не paginated) |
| GET | `/api/v1/tags/{id}/` | 🔓 anon | 60/min | Детальная карточка тега |

---

## Список категорий

`GET /api/v1/categories/`

**Auth:** 🔓 anon
**Throttle:** 60/min

### Описание

Возвращает полный список категорий в алфавитном порядке. Поддерживает поиск по имени через `?search=`. Ответ обёрнут в стандартный paginated-конверт — см. [conventions.md#pagination](../conventions.md#pagination).

Категории управляются исключительно через Django admin (staff-пользователи). Клиент не может создать категорию сам.

### Query-параметры

| Параметр | Тип | Required | Default | Описание |
|---|---|---|---|---|
| `search` | string | нет | — | Поиск по полю `name` (case-insensitive contains) |
| `page` | integer | нет | 1 | Номер страницы |
| `page_size` | integer | нет | 20 | Размер страницы (max 100) |

### Ответы

**200 OK**

```json
{
  "count": 14,
  "next": null,
  "previous": null,
  "results": [
    {
      "id": 3,
      "name": "Азия",
      "icon": "🥢",
      "color": "",
      "mode": "cuisines"
    },
    {
      "id": 1,
      "name": "Бургеры",
      "icon": "🍔",
      "color": "",
      "mode": "dishes"
    }
  ]
}
```

| Поле | Тип | Описание |
|---|---|---|
| `id` | integer | Идентификатор категории |
| `name` | string | Название категории (уникальное) |
| `icon` | string | Один эмодзи-символ. Может быть пустой строкой — фронт использует fallback из `lib/categories.ts` |
| `color` | string | HEX-цвет фона чипа (`#RRGGBB`) или пустая строка |
| `mode` | string | `"dishes"` — вкладка «Блюда»; `"cuisines"` — вкладка «Кухни» |

### Пример

```bash
export BASE_URL=https://foody.press/api/v1

curl -G "${BASE_URL}/categories/" \
  --data-urlencode "search=пицца"
```

---

## Создать категорию

`POST /api/v1/categories/`

**Auth:** 👮 staff
**Throttle:** 300/min

### Описание

Создаёт новую категорию. Доступно только пользователям с `is_staff=True`. Обычный авторизованный пользователь получает 403. Аноним получает 401. О получении staff-токена — см. [auth.md#staff-access](../auth.md#staff-access).

### Тело запроса

```json
{
  "name": "Завтраки",
  "icon": "🥐",
  "color": "#FFF3E0",
  "mode": "dishes"
}
```

| Поле | Тип | Required | Описание |
|---|---|---|---|
| `name` | string | **да** | Название категории. Уникальное, max 100 символов |
| `icon` | string | нет | Один эмодзи. Пустая строка допустима |
| `color` | string | нет | HEX-цвет (`#RRGGBB`), max 7 символов. Пустая строка допустима |
| `mode` | string | нет | `"dishes"` (по умолчанию) или `"cuisines"` |

### Ответы

**201 Created**

```json
{
  "id": 15,
  "name": "Завтраки",
  "icon": "🥐",
  "color": "#FFF3E0",
  "mode": "dishes"
}
```

**400 Bad Request** — пропущено обязательное поле или передано недопустимое значение

```json
{
  "name": ["Обязательное поле."]
}
```

```json
{
  "mode": ["Значения invalid нет среди допустимых вариантов."]
}
```

**401 Unauthorized** — запрос без токена; см. [errors.md#401](../errors.md#401)

```json
{
  "detail": "Учетные данные не были предоставлены."
}
```

**403 Forbidden** — авторизованный пользователь без прав staff; см. [errors.md#403](../errors.md#403)

```json
{
  "detail": "У вас недостаточно прав для выполнения данного действия."
}
```

**429 Too Many Requests** — см. [conventions.md#throttle](../conventions.md#throttle)

### Пример

```bash
export BASE_URL=https://foody.press/api/v1
export TOKEN=<staff-токен, см. auth.md#staff-access>

curl -X POST "${BASE_URL}/categories/" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json" \
  -d '{"name":"Завтраки","icon":"🥐","mode":"dishes"}'
```

---

## Детальная карточка категории

`GET /api/v1/categories/{id}/`

**Auth:** 🔓 anon
**Throttle:** 60/min

### Описание

Возвращает одну категорию по числовому `id`.

### Параметры пути

| Параметр | Тип | Описание |
|---|---|---|
| `id` | integer | Идентификатор категории |

### Ответы

**200 OK**

```json
{
  "id": 3,
  "name": "Азия",
  "icon": "🥢",
  "color": "",
  "mode": "cuisines"
}
```

**404 Not Found** — категория с таким `id` не существует; см. [errors.md#404](../errors.md#404)

```json
{
  "detail": "No Category matches the given query."
}
```

### Пример

```bash
export BASE_URL=https://foody.press/api/v1

curl "${BASE_URL}/categories/3/"
```

---

## Обновить категорию

`PATCH /api/v1/categories/{id}/`
`PUT /api/v1/categories/{id}/`

**Auth:** 👮 staff
**Throttle:** 300/min

### Описание

PATCH выполняет частичное обновление — достаточно передать только изменяемые поля. PUT требует передать все поля полностью.

### Параметры пути

| Параметр | Тип | Описание |
|---|---|---|
| `id` | integer | Идентификатор категории |

### Тело запроса (PATCH, частичное)

```json
{
  "icon": "🍕",
  "color": "#FF5722"
}
```

Поля: `name`, `icon`, `color`, `mode` — те же, что при создании.

### Ответы

**200 OK** — обновлённая категория в том же формате, что и при создании.

```json
{
  "id": 2,
  "name": "Пицца",
  "icon": "🍕",
  "color": "#FF5722",
  "mode": "dishes"
}
```

**400 Bad Request** — невалидные данные (те же форматы, что при POST)

**401 Unauthorized** — см. [errors.md#401](../errors.md#401)

**403 Forbidden** — см. [errors.md#403](../errors.md#403)

**404 Not Found** — категория не найдена; см. [errors.md#404](../errors.md#404)

### Пример

```bash
export BASE_URL=https://foody.press/api/v1
export TOKEN=<staff-токен>
export CATEGORY_ID=2

curl -X PATCH "${BASE_URL}/categories/${CATEGORY_ID}/" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json" \
  -d '{"color":"#FF5722"}'
```

---

## Удалить категорию

`DELETE /api/v1/categories/{id}/`

**Auth:** 👮 staff
**Throttle:** 300/min

### Описание

Удаляет категорию. Операция необратима. Связанные блюда и рестораны теряют эту категорию (M2M-связь удаляется каскадно).

### Параметры пути

| Параметр | Тип | Описание |
|---|---|---|
| `id` | integer | Идентификатор категории |

### Ответы

**204 No Content** — успешное удаление, тела ответа нет.

**401 Unauthorized** — см. [errors.md#401](../errors.md#401)

**403 Forbidden** — см. [errors.md#403](../errors.md#403)

**404 Not Found** — см. [errors.md#404](../errors.md#404)

### Пример

```bash
export BASE_URL=https://foody.press/api/v1
export TOKEN=<staff-токен>
export CATEGORY_ID=15

curl -X DELETE "${BASE_URL}/categories/${CATEGORY_ID}/" \
  -H "Authorization: Bearer ${TOKEN}"
```

---

## Популярные категории

`GET /api/v1/categories/popular/`

**Auth:** 🔓 anon
**Throttle:** 60/min

### Описание

Возвращает топ-N категорий, отсортированных по количеству **опубликованных** (`approved`) постов, связанных с категорией через блюда (`dish.categories`) или рестораны (`restaurant.categories`). Один пост учитывается один раз даже если он связан с категорией через оба пути.

Ответ — **чистый массив**, без paginated-конверта `{count, next, results}`.

### Query-параметры

| Параметр | Тип | Required | Default | Описание |
|---|---|---|---|---|
| `limit` | integer | нет | 8 | Количество категорий. Автоматически ограничивается диапазоном [1, 50] |

### Ответы

**200 OK** — массив объектов категорий

```json
[
  {
    "id": 3,
    "name": "Азия",
    "icon": "🥢",
    "color": "",
    "mode": "cuisines"
  },
  {
    "id": 14,
    "name": "Альтернатива",
    "icon": "🥗",
    "color": "",
    "mode": "cuisines"
  },
  {
    "id": 10,
    "name": "Бары и пабы",
    "icon": "🍺",
    "color": "",
    "mode": "dishes"
  }
]
```

### Замечания

Если `limit` нельзя привести к числу — молча используется default 8. Значения вне диапазона [1, 50] зажимаются: `limit=0` → 1, `limit=100` → 50.

### Пример

```bash
export BASE_URL=https://foody.press/api/v1

curl "${BASE_URL}/categories/popular/?limit=5"
```

---

## Теги

### Список тегов

`GET /api/v1/tags/`

**Auth:** 🔓 anon
**Throttle:** 60/min

#### Описание

Возвращает **все** теги одним массивом — пагинация отсутствует (`pagination_class = None`). Теги отсортированы по убыванию `usage_count` (самые популярные первыми), при равенстве — по имени.

Поддерживает поиск по имени через `?search=` (case-insensitive contains).

Этот эндпоинт используется фронтом для автодополнения тегов при создании поста и для страницы поиска.

#### Query-параметры

| Параметр | Тип | Required | Default | Описание |
|---|---|---|---|---|
| `search` | string | нет | — | Поиск по полю `name` (icontains) |

#### Ответы

**200 OK** — массив тегов (не paginated)

```json
[
  {
    "id": 9,
    "name": "русская"
  },
  {
    "id": 23,
    "name": "сытно"
  },
  {
    "id": 48,
    "name": "американская"
  }
]
```

| Поле | Тип | Описание |
|---|---|---|
| `id` | integer | Идентификатор тега |
| `name` | string | Название тега (lowercase, уникальное, max 50 символов) |

#### Пример

```bash
export BASE_URL=https://foody.press/api/v1

# Все теги
curl "${BASE_URL}/tags/"

# Поиск по подстроке
curl -G "${BASE_URL}/tags/" --data-urlencode "search=рус"
```

---

### Детальная карточка тега

`GET /api/v1/tags/{id}/`

**Auth:** 🔓 anon
**Throttle:** 60/min

#### Описание

Возвращает один тег по числовому `id`.

#### Параметры пути

| Параметр | Тип | Описание |
|---|---|---|
| `id` | integer | Идентификатор тега |

#### Ответы

**200 OK**

```json
{
  "id": 9,
  "name": "русская"
}
```

**404 Not Found** — тег с таким `id` не существует; см. [errors.md#404](../errors.md#404)

#### Пример

```bash
export BASE_URL=https://foody.press/api/v1

curl "${BASE_URL}/tags/9/"
```

---

### Замечания по тегам

Теги создаются автоматически при публикации поста: поле `tags_list` в `POST /api/v1/posts/` принимает список строк, каждая из которых приводится к lowercase и создаётся через `get_or_create`. Прямого эндпоинта для создания тегов нет — `TagViewSet` предоставляет только чтение (ListModelMixin + RetrieveModelMixin).

Поле `usage_count` обновляется через Django-сигналы. Используйте его для ранжирования в подсказках.

Для фильтрации постов по тегу используйте [conventions.md#filters](../conventions.md#filters): `?tag_id=N` или `?tag_name=<name>`.
