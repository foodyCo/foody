# Аутентификация

Foody использует JWT-токены (`djangorestframework-simplejwt`) с логином по email. Сервер
выдаёт пару токенов `(access, refresh)`. `access` живёт 60 минут, `refresh` — 24 часа.

> Связанные документы: общий формат заголовков и базовый URL — в
> [conventions.md#base-url](conventions.md#base-url) и [conventions.md#throttle](conventions.md#throttle).
> Полный справочник кодов ответа — в [errors.md](errors.md).

---

## Резюме эндпоинтов

| Метод | Путь | Auth | Throttle |
|---|---|---|---|
| POST | `/api/v1/users/register/` | 🔓 anon | `anon 60/min` |
| GET | `/api/v1/users/check-email/` | 🔓 anon | `anon 60/min` |
| GET | `/api/v1/users/check-username/` | 🔓 anon | `anon 60/min` |
| POST | `/api/v1/auth/token/` | 🔓 anon | `login 10/min` |
| POST | `/api/v1/auth/token/refresh/` | 🔓 anon | `login 10/min` |
| DELETE | `/api/v1/users/me/` | 🔒 user | `user 300/min` |

---

## Authorization-заголовок {#header}

Все авторизованные запросы используют схему **Bearer**:

```
Authorization: Bearer <access_token>
```

Настройка `SIMPLE_JWT.AUTH_HEADER_TYPES = ('Bearer',)`. Другие схемы (`Token`, `JWT`)
сервер не принимает — будет 401 с `code: "bad_authorization_header"`. Сериализатор
аутентификации единственный — `JWTAuthentication`, сессионных cookie REST API не
использует.

---

## Регистрация {#register}

`POST /api/v1/users/register/`

**Auth:** 🔓 anon
**Throttle:** `anon 60/min` (см. [conventions.md#throttle](conventions.md#throttle))

### Тело запроса

```json
{
  "username": "newchef",
  "email": "newchef@example.com",
  "password": "VerySecure123!",
  "password_confirm": "VerySecure123!",
  "full_name": "New Chef",
  "city": "Москва"
}
```

| Поле | Тип | Required | Описание |
|---|---|---|---|
| `username` | string | да | Уникальный, ≤150 символов |
| `email` | string (email) | да | Уникальный, нормализуется в lower-case в `EmailBackend` |
| `password` | string | да | Прогоняется через Django `validate_password` (длина ≥8, не цифровой, не из топ-паролей) |
| `password_confirm` | string | да | Должен совпадать с `password` |
| `full_name` | string | нет | До 120 символов |
| `city` | string | **да** | До 100 символов, не пустой |

### Ответ 201 Created

Возвращает данные созданного пользователя (без `password`):

```json
{
  "id": 142,
  "username": "newchef",
  "email": "newchef@example.com",
  "full_name": "New Chef",
  "city": "Москва"
}
```

### Ответ 400 Bad Request

Реальная серверная реакция на невалидные данные (см.
[errors.md#drf-formats](errors.md#drf-formats)):

```json
{
  "email": ["Введите правильный адрес электронной почты."],
  "password": [
    "Введённый пароль слишком короткий. Он должен состоять из как минимум 8 символов.",
    "Введённый пароль слишком широко распространён.",
    "Введённый пароль состоит только из цифр."
  ],
  "city": ["Обязательное поле."]
}
```

Дубль по email/username (включая параллельные регистрации — есть защита от race
через `IntegrityError`):

```json
{
  "username": ["user с таким username уже существует."],
  "email": ["user с таким email уже существует."]
}
```

Несовпадение паролей:

```json
{"password_confirm": "Пароли не совпадают."}
```

### Пример

```bash
curl -X POST "$BASE_URL/users/register/" \
  -H 'Content-Type: application/json' \
  -d '{"username":"newchef","email":"newchef@example.com","password":"VerySecure123!","password_confirm":"VerySecure123!","full_name":"New Chef","city":"Москва"}'
```

---

## Проверка доступности email и username {#availability-checks}

Лёгкие GET-эндпоинты для live-валидации формы регистрации на фронте — позволяют
показать «занято / свободно» без отправки формы. Anon, throttle `anon 60/min`.

### `GET /api/v1/users/check-email/`

Query: `email` (обязателен, нормализуется в lower-case).

**200 OK:**

```json
{"available": false, "email": "test_user1@test.local"}
```

**400 Bad Request** — пустой параметр:

```json
{"error": "email is required"}
```

### `GET /api/v1/users/check-username/`

Query: `username` (обязателен, регистр сохраняется, сравнение через `iexact`).

**200 OK:**

```json
{"available": false, "username": "test_user1_renamed"}
```

**400 Bad Request:**

```json
{"error": "username is required"}
```

### Пример

```bash
curl "$BASE_URL/users/check-email/?email=newchef@example.com"
curl "$BASE_URL/users/check-username/?username=newchef"
```

> Эти эндпоинты не являются гарантией «email будет свободен в момент регистрации»
> — между проверкой и `POST /users/register/` может зарегистрироваться другой
> пользователь. Финальная защита от race — на сервере в `UserRegistrationSerializer`.

---

## Получение JWT-токена {#jwt-obtain}

`POST /api/v1/auth/token/`

**Auth:** 🔓 anon
**Throttle:** `login 10/min` (отдельный scope, **считается по IP**, не по аккаунту —
наследуется от `AnonRateThrottle`; 60-попыточный default «anon» здесь не действует).

Логин — по **email**, не по username. Сервер использует кастомный
`EmailBackend` (`backend/users/auth_backends.py`) и `EmailTokenObtainPairSerializer`,
у которого `username_field = "email"` и `attrs["email"]` приводится к lower-case
перед поиском в БД.

### Тело запроса

```json
{
  "email": "test_user1@test.local",
  "password": "foodytest123"
}
```

### Ответ 200 OK

```json
{
  "refresh": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "access": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

Время жизни (см. `SIMPLE_JWT` в `backend/config/settings.py`):

| Токен | Назначение | Жизнь |
|---|---|---|
| `access` | подставляется в `Authorization: Bearer ...` | 60 минут |
| `refresh` | обменивается на новый `access` через `/auth/token/refresh/` | 24 часа |

### Ответ 401 Unauthorized

Реальная реакция на неверный пароль (текст из `simplejwt`, **не локализован**):

```json
{"detail": "No active account found with the given credentials"}
```

### Ответ 429 Too Many Requests

Превышение `login 10/min`. Сервер возвращает заголовок `Retry-After` с количеством
секунд до сброса лимита. Подробнее — см. [errors.md#429](errors.md#429).

```http
HTTP/2 429
retry-after: 8
content-type: application/json

{"detail": "Запрос был проигнорирован. Expected available in 8 seconds."}
```

### Пример

```bash
TOKEN=$(curl -s -X POST "$BASE_URL/auth/token/" \
  -H 'Content-Type: application/json' \
  -d '{"email":"test_user1@test.local","password":"foodytest123"}' \
  | jq -r .access)
echo "$TOKEN"
```

---

## Refresh access-токена {#jwt-refresh}

`POST /api/v1/auth/token/refresh/`

**Auth:** 🔓 anon (валидируется сам refresh-токен)
**Throttle:** `login 10/min` (тот же IP-bucket, что и `/auth/token/`).

### Тело запроса

```json
{"refresh": "<refresh_token>"}
```

### Ответ 200 OK

```json
{"access": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."}
```

> По умолчанию `ROTATE_REFRESH_TOKENS=False` — новый `refresh` не выдаётся, старый
> продолжает работать до своего expiry (24 часа от первой выдачи). При истечении
> refresh-токена клиент обязан заново выполнить [`/auth/token/`](#jwt-obtain).

### Ответ 401 Unauthorized

Неподписанный / истёкший / некорректный refresh:

```json
{
  "detail": "Token is invalid or expired",
  "code": "token_not_valid"
}
```

### Refresh-стратегия для фронта (рекомендация)

Веб-фронт Foody на NextAuth v5 выполняет refresh **за 60 секунд до expiry**
access-токена (см. `frontend/src/auth.ts`). Это рекомендация, не контракт
сервера: бэкенд просто принимает валидный refresh и отдаёт новый access.

Минимальный набор шагов для произвольного клиента:

1. Сохранить пару `(access, refresh)` и момент выдачи.
2. Перед каждым запросом проверить, что до expiry `access` осталось > 60 сек.
3. Если меньше — выполнить `POST /auth/token/refresh/`, заменить access.
4. На 401 с `code: "token_not_valid"` от любого эндпоинта — попытаться refresh
   один раз; если повторный 401 — разлогинить юзера.

### Пример

```bash
NEW_ACCESS=$(curl -s -X POST "$BASE_URL/auth/token/refresh/" \
  -H 'Content-Type: application/json' \
  -d "{\"refresh\":\"$REFRESH\"}" \
  | jq -r .access)
```

---

## Staff-доступ {#staff-access}

Все эндпоинты под `/api/v1/moderation/` требуют пользователя с `is_staff=True`
(класс `IsAdminUser`). Для тестов используется `admin@example.com / admin123`
из dev-сидов (см. CLAUDE.md и `_pipeline.md §4`).

Получение staff-токена — обычный `/auth/token/`:

```bash
ADMIN_TOKEN=$(curl -s -X POST "$BASE_URL/auth/token/" \
  -H 'Content-Type: application/json' \
  -d '{"email":"admin@example.com","password":"admin123"}' \
  | jq -r .access)
```

Проверить, что текущий пользователь — staff:

```bash
curl "$BASE_URL/users/me/" -H "Authorization: Bearer $ADMIN_TOKEN" | jq .is_staff
# true
```

Запрос к `/moderation/` без staff-токена возвращает 403:

```json
{"detail": "У вас недостаточно прав для выполнения данного действия."}
```

> На свежей prod-БД пароль `admin123` может быть изменён в рамках хардинга — если
> логин падает с `No active account found ...`, попросите администратора сбросить
> пароль или используйте свой staff-аккаунт.

См. также [reference/moderation.md](reference/moderation.md).

---

## Удаление собственного аккаунта {#account-delete}

`DELETE /api/v1/users/me/`

**Auth:** 🔒 user
**Throttle:** `user 300/min`

Удаляет учётную запись текущего пользователя. Все связанные сущности удаляются
каскадно через `on_delete=CASCADE/SET_NULL` (посты, комментарии, лайки,
сохранения, подписки).

### Ответ 204 No Content

Тело пустое.

### Важно: JWT остаётся валидным до expiry

После 204 клиент **обязан** сам:

1. Очистить локально сохранённые `access` и `refresh` (cookie / localStorage).
2. Не делать новых запросов с этим токеном.

Сервер не ведёт чёрный список JWT — без явного выкидывания токена прошлый
access-токен будет валидно подписан вплоть до своих 60 минут expiry (но
любой запрос вернёт 404 на `/users/me/`, потому что юзера больше нет).

### Пример

```bash
curl -X DELETE "$BASE_URL/users/me/" -H "Authorization: Bearer $TOKEN"
# HTTP/2 204
```

---

## NextAuth-обёртка (фронт)

Веб-фронт Foody (`frontend/src/auth.ts`) использует NextAuth v5 с Credentials
provider. NextAuth хранит выданную Django пару `(access, refresh)` в собственной
JWT-сессии и автоматически делает refresh за 60 секунд до expiry. Для серверных
вызовов на API он подставляет `Authorization: Bearer <access>` в `frontend/src/lib/api.ts`.

Для внешних клиентов (сторонние интеграторы, мобильные приложения) эта обёртка
прозрачна — взаимодействие идёт строго по REST-эндпоинтам выше. NextAuth-роуты
`/api/auth/*` находятся **в Next.js**, не в Django (см. CLAUDE.md §«Request Flow»),
и для прямого использования API не нужны.
